#!/bin/bash

# Script pour rendre les fichiers exécutables
echo "🔧 Configuration des permissions pour Linux..."

# Scripts principaux
chmod +x install_linux.sh
chmod +x start_app.sh

# Scripts Python
chmod +x flask_web/detect_port.py
chmod +x flask_web/app.py
chmod +x flask_web/test_db.py
chmod +x python_controller/ax12_controller.py

echo "✅ Permissions configurées!"
echo ""
echo "Vous pouvez maintenant utiliser:"
echo "./install_linux.sh   # Installation complète"
echo "./start_app.sh       # Lancement de l'application"
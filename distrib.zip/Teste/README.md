# AX-12 Servo Controller

Ce projet permet de contrôler un servo moteur AX-12 via un Arduino Mega et un script Python. Le script Python envoie des commandes d'angle à l'Arduino, qui transmet ensuite les commandes au servo AX-12.

## Matériel requis

- Arduino Mega 2560
- Servo moteur AX-12
- Alimentation 12V pour le servo
- Câbles de connexion
- Résistance de pull-up 10kΩ (optionnelle)

## Câblage

### Arduino Mega vers AX-12
- **TX1 (Pin 18)** → **Data** du servo AX-12
- **RX1 (Pin 19)** → **Data** du servo AX-12 (avec pull-up 10kΩ vers 3.3V)
- **Pin 2** → **Direction** du servo AX-12 (pour communication half-duplex)
- **GND** → **GND** commun
- **VCC 12V** → **VCC** du servo AX-12

### Connexion USB
- Arduino Mega connecté via USB au PC (port COM6 sur Windows)

## Installation

### 1. Arduino IDE
1. Ouvrir `arduino_servo/arduino_servo.ino` dans l'Arduino IDE
2. Sélectionner la carte "Arduino Mega 2560"
3. Sélectionner le port COM6
4. Téléverser le code sur l'Arduino

### 2. Python
1. Installer Python 3.6 ou plus récent
2. Installer les dépendances :
   ```bash
   pip install -r requirements.txt
   ```

## Utilisation

### Interface Web Flask (Recommandé)
```bash
cd flask_web
python app.py
```
Puis ouvrir http://localhost:5000 dans votre navigateur

### Script Python (Ligne de commande)
```bash
cd python_controller
python ax12_controller.py
```

### Interface Web
- **Zone de saisie** : Entrez l'angle désiré (0-300 degrés)
- **Bouton "Déplacer"** : Envoie la commande au servo
- **Boutons rapides** : Angles prédéfinis (0°, 90°, 180°, 270°, 150°, 300°)
- **Boutons de contrôle** : Connecter/Déconnecter, Ping, Status
- **Indicateur de connexion** : Statut en temps réel

### Commandes ligne de commande
- `ex<angle>` - Déplacer le servo à l'angle spécifié (0-300 degrés)
  - Exemples : `ex90`, `ex180`, `ex0`
- `ping` - Vérifier si le servo répond
- `status` - Obtenir les informations du servo (position, vitesse, charge, tension, température)
- `quit` - Quitter le programme

### Exemple d'utilisation
```
Enter command: ex90
Arduino: Moving to: 90 degrees

Enter command: ex180
Arduino: Moving to: 180 degrees

Enter command: status
Arduino: Current position: 180 degrees
Arduino: Current speed: 0
Arduino: Current load: 0
Arduino: Voltage: 12.0V
Arduino: Temperature: 25°C
```

## Configuration

### ID du servo
Par défaut, le code utilise l'ID 1 pour le servo. Pour changer l'ID :
1. Modifier la constante `AX12_ID` dans le code Arduino
2. Ou utiliser le logiciel Dynamixel Wizard pour changer l'ID du servo

### Vitesse de communication
- **Arduino ↔ PC** : 9600 baud
- **Arduino ↔ AX-12** : 1000000 baud (1 Mbps)

### Plage d'angles
- **AX-12** : 0-300 degrés (0-1023 en position AX-12)
- Le code convertit automatiquement les degrés en position AX-12

## Dépannage

### Problèmes de connexion
1. **"Error connecting to COM6"**
   - Vérifier que l'Arduino est connecté sur COM6
   - Fermer l'Arduino IDE ou tout autre programme utilisant le port série
   - Redémarrer l'Arduino

2. **"AX-12 servo not responding"**
   - Vérifier le câblage (TX1, RX1, Direction, GND)
   - Vérifier l'alimentation 12V du servo
   - Vérifier l'ID du servo (par défaut ID=1)
   - Tester avec la commande `ping`

### Problèmes de mouvement
1. **Le servo ne bouge pas**
   - Vérifier l'alimentation 12V
   - Vérifier les connexions TX1/RX1
   - Vérifier que l'ID du servo correspond

2. **Mouvement erratique**
   - Vérifier la qualité des connexions
   - Vérifier la tension d'alimentation
   - Ajouter une résistance de pull-up 10kΩ sur la ligne de données

### Problèmes de communication
1. **Pas de réponse de l'Arduino**
   - Vérifier que le code Arduino est téléversé
   - Vérifier le port COM6
   - Redémarrer l'Arduino

2. **Erreurs de transmission**
   - Vérifier le câblage TX1/RX1
   - Vérifier la pin de direction (Pin 2)
   - Vérifier la vitesse de communication

## Structure du projet

```
├── arduino_servo/
│   └── arduino_servo.ino    # Code Arduino pour contrôler AX-12
├── python_controller/
│   └── ax12_controller.py   # Script Python pour envoyer commandes
├── flask_web/
│   ├── app.py               # Application Flask web
│   └── templates/
│       └── index.html       # Interface web HTML
├── requirements.txt         # Dépendances Python
└── README.md               # Documentation
```

## Protocole de communication

### Arduino ↔ PC (USB Serial)
- Format : `ex<angle>\n`
- Exemple : `ex90\n`

### Arduino ↔ AX-12 (Serial1)
- Protocole Dynamixel AX-12
- Vitesse : 1 Mbps
- Communication half-duplex avec pin de direction

## Notes techniques

- Le servo AX-12 utilise le protocole Dynamixel
- Communication half-duplex nécessitant une pin de direction
- Conversion automatique des degrés (0-300) en position AX-12 (0-1023)
- Gestion des erreurs et vérification de la communication
- Support des commandes de diagnostic (ping, status)

#!/usr/bin/env python3
"""
AX-12 Servo Controller
Sends angle commands to Arduino Mega over serial port
Arduino controls AX-12 servo via Serial1 (TX1/RX1)

Usage:
    python ax12_controller.py
    Then enter commands like: ex90, ex180, etc.
    
Compatible with:
    - Windows: COM ports (COM6, COM3, etc.)
    - Linux: /dev/ttyUSB0, /dev/ttyACM0, etc.
"""

import serial
import serial.tools.list_ports
import time
import sys
import os
import platform

class AX12Controller:
    def __init__(self, port=None, baudrate=9600, timeout=1):
        """
        Initialize connection to Arduino
        
        Args:
            port (str): Serial port (auto-detect if None)
            baudrate (int): Baud rate for communication
            timeout (int): Timeout for serial operations
        """
        self.port = port or self._detect_arduino_port()
        self.baudrate = baudrate
        self.timeout = timeout
        self.serial_connection = None
        
    def _detect_arduino_port(self):
        """Auto-detect Arduino port based on OS"""
        system = platform.system().lower()
        
        if system == "windows":
            # Windows: Try common COM ports
            for i in range(1, 20):
                port = f"COM{i}"
                if self._test_port(port):
                    return port
            return "COM6"  # Fallback
            
        elif system == "linux":
            # Linux: Check USB serial devices
            usb_ports = ["/dev/ttyUSB0", "/dev/ttyUSB1", "/dev/ttyACM0", "/dev/ttyACM1"]
            for port in usb_ports:
                if os.path.exists(port) and self._test_port(port):
                    return port
            return "/dev/ttyUSB0"  # Fallback
            
        else:
            # macOS ou autres
            return "/dev/cu.usbserial-*"
    
    def _test_port(self, port):
        """Test if a port is available and responsive"""
        try:
            with serial.Serial(port, self.baudrate, timeout=0.5) as test_conn:
                return True
        except:
            return False
        
    def connect(self):
        """Establish serial connection to Arduino"""
        try:
            self.serial_connection = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=self.timeout
            )
            time.sleep(2)  # Wait for Arduino to initialize
            print(f"Connected to {self.port} at {self.baudrate} baud")
            return True
        except serial.SerialException as e:
            print(f"Error connecting to {self.port}: {e}")
            return False
    
    def disconnect(self):
        """Close serial connection"""
        if self.serial_connection and self.serial_connection.is_open:
            self.serial_connection.close()
            print("Disconnected from Arduino")
    
    def send_command(self, command):
        """
        Send command to Arduino
        
        Args:
            command (str): Command to send (e.g., 'ex90')
        """
        if not self.serial_connection or not self.serial_connection.is_open:
            print("Not connected to Arduino")
            return False
        
        try:
            # Send command with newline
            self.serial_connection.write((command + '\n').encode())
            self.serial_connection.flush()
            
            # Wait for response
            time.sleep(0.1)
            
            # Read response if available
            if self.serial_connection.in_waiting > 0:
                response = self.serial_connection.readline().decode().strip()
                if response:
                    print(f"Arduino: {response}")
            
            return True
        except Exception as e:
            print(f"Error sending command: {e}")
            return False
    
    def move_servo(self, angle):
        """
        Move servo to specified angle
        
        Args:
            angle (int): Target angle (0-300 degrees)
        """
        if not (0 <= angle <= 300):
            print("Error: Angle must be between 0 and 300 degrees")
            return False
        
        command = f"ex{angle}"
        return self.send_command(command)
    
    def ping_servo(self):
        """Ping the servo to check if it's responding"""
        return self.send_command("ping")
    
    def get_status(self):
        """Get servo status information"""
        return self.send_command("status")
    
    def interactive_mode(self):
        """Run interactive command mode"""
        print("\n=== AX-12 Servo Controller ===")
        print("Commands:")
        print("  ex<angle>  - Move to angle (0-300 degrees)")
        print("  ping       - Ping servo")
        print("  status     - Get servo status")
        print("  quit       - Exit program")
        print("Examples: ex90, ex180, ex0")
        print("=" * 30)
        
        while True:
            try:
                command = input("\nEnter command: ").strip().lower()
                
                if command == 'quit' or command == 'exit':
                    break
                elif command == 'ping':
                    self.ping_servo()
                elif command == 'status':
                    self.get_status()
                elif command.startswith('ex'):
                    try:
                        angle = int(command[2:])
                        self.move_servo(angle)
                    except ValueError:
                        print("Error: Invalid angle format. Use ex<number> (e.g., ex90)")
                else:
                    print("Unknown command. Use: ex<angle>, ping, status, or quit")
                    
            except KeyboardInterrupt:
                print("\nExiting...")
                break
            except Exception as e:
                print(f"Error: {e}")

def main():
    """Main function"""
    print("AX-12 Servo Controller")
    print("Connecting to Arduino on COM6...")
    
    # Create controller instance
    controller = AX12Controller(port='COM6')
    
    # Connect to Arduino
    if not controller.connect():
        print("Failed to connect to Arduino. Please check:")
        print("1. Arduino is connected to COM6")
        print("2. Arduino firmware is uploaded")
        print("3. No other programs are using the serial port")
        sys.exit(1)
    
    try:
        # Run interactive mode
        controller.interactive_mode()
    finally:
        # Always disconnect when done
        controller.disconnect()

if __name__ == "__main__":
    main()

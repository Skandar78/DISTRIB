#!/usr/bin/env python3
"""
Script de diagnostic pour la page admin
"""

import sys
import os
import sqlite3
import json

# Ajouter le chemin du projet
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def check_database():
    """Vérifier la base de données"""
    print("🔍 Vérification de la base de données...")
    
    try:
        # Chercher le fichier de DB
        config_path = 'config.json'
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = json.load(f)
            db_file = config.get('db_file', 'distributor.db')
        else:
            db_file = 'distributor.db'
        
        if not os.path.exists(db_file):
            print(f"❌ Base de données non trouvée: {db_file}")
            return False
        
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        
        # Vérifier les tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        print(f"✅ Tables trouvées: {[t[0] for t in tables]}")
        
        # Vérifier les utilisateurs
        cursor.execute("SELECT COUNT(*) FROM users;")
        user_count = cursor.fetchone()[0]
        print(f"👥 Utilisateurs: {user_count}")
        
        # Vérifier les produits
        cursor.execute("SELECT COUNT(*) FROM products;")
        product_count = cursor.fetchone()[0]
        print(f"📦 Produits: {product_count}")
        
        # Vérifier les transactions
        cursor.execute("SELECT COUNT(*) FROM transactions;")
        transaction_count = cursor.fetchone()[0]
        print(f"🧾 Transactions: {transaction_count}")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Erreur base de données: {e}")
        return False

def check_config():
    """Vérifier la configuration"""
    print("\n🔍 Vérification de la configuration...")
    
    try:
        if os.path.exists('config.json'):
            with open('config.json', 'r') as f:
                config = json.load(f)
            
            print(f"✅ Port série: {config.get('com_port', 'Non défini')}")
            print(f"✅ Admin user: {config.get('admin_username', 'Non défini')}")
            print(f"✅ DB file: {config.get('db_file', 'Non défini')}")
            return True
        else:
            print("❌ Fichier config.json non trouvé")
            return False
            
    except Exception as e:
        print(f"❌ Erreur config: {e}")
        return False

def check_static_files():
    """Vérifier les fichiers statiques"""
    print("\n🔍 Vérification des fichiers statiques...")
    
    files_to_check = [
        'static/js/admin.js',
        'static/js/kiosk.js',
        'static/css/style.css',
        'templates/admin.html'
    ]
    
    all_good = True
    for file_path in files_to_check:
        if os.path.exists(file_path):
            print(f"✅ {file_path}")
        else:
            print(f"❌ {file_path} manquant")
            all_good = False
    
    return all_good

def test_admin_login():
    """Tester la connexion admin"""
    print("\n🔍 Test de connexion admin...")
    
    try:
        if os.path.exists('config.json'):
            with open('config.json', 'r') as f:
                config = json.load(f)
            
            admin_user = config.get('admin_username', 'admin')
            admin_pass = config.get('admin_password', 'admin')
            
            print(f"📋 Identifiants admin:")
            print(f"   Utilisateur: {admin_user}")
            print(f"   Mot de passe: {admin_pass}")
            print("ℹ️ Utilisez ces identifiants pour vous connecter")
            
            return True
        else:
            print("❌ Impossible de récupérer les identifiants")
            return False
            
    except Exception as e:
        print(f"❌ Erreur: {e}")
        return False

def main():
    print("🚀 Diagnostic de la page admin Vendikit\n")
    
    results = []
    results.append(check_config())
    results.append(check_database())
    results.append(check_static_files())
    results.append(test_admin_login())
    
    print(f"\n📊 Résultats: {sum(results)}/{len(results)} tests réussis")
    
    if all(results):
        print("\n✅ Tout semble en ordre!")
        print("🔗 Accédez à: http://localhost:5000/admin")
        print("🔑 Connectez-vous d'abord si nécessaire")
    else:
        print("\n❌ Des problèmes ont été détectés")
        print("🛠️ Corrigez les erreurs ci-dessus")
    
    print("\n💡 Si le problème persiste:")
    print("   1. Redémarrez l'application Flask")
    print("   2. Videz le cache du navigateur (Ctrl+F5)")
    print("   3. Vérifiez la console du navigateur (F12)")

if __name__ == "__main__":
    main()
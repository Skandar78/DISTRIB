"""
Script de test RFID - vérifie la communication avec l'Arduino
"""
import serial
import time

PORT = 'COM6'
BAUD = 9600

print(f"=== Test RFID Arduino ===")
print(f"Port: {PORT}, Baudrate: {BAUD}")

try:
    ser = serial.Serial(PORT, BAUD, timeout=1)
    time.sleep(2)  # Attendre que l'Arduino démarre
    print("✓ Connexion établie\n")
    
    # Vider le buffer
    while ser.in_waiting > 0:
        line = ser.readline().decode('utf-8', errors='ignore').strip()
        print(f"[INIT] {line}")
    
    print("\n--- Envoi de la commande 'rfid' ---")
    ser.write(b'rfid\n')
    ser.flush()
    print("Commande envoyée. En attente de réponse (max 10 secondes)...")
    print(">>> Approchez votre carte RFID maintenant <<<\n")
    
    start = time.time()
    rfid_detected = False
    
    while time.time() - start < 10:
        if ser.in_waiting > 0:
            line = ser.readline().decode('utf-8', errors='ignore').strip()
            if line:
                print(f"[RX] {line}")
                if line.startswith('RFID:'):
                    uid = line.split(':', 1)[1].strip()
                    if uid != 'TIMEOUT':
                        print(f"\n✅ Carte détectée ! UID: {uid}")
                        rfid_detected = True
                        break
                    else:
                        print("⏱️  Timeout Arduino - aucune carte détectée dans les 3 secondes")
                        break
        time.sleep(0.1)
    
    if not rfid_detected and time.time() - start >= 10:
        print("\n❌ Aucune réponse de l'Arduino après 10 secondes")
        print("Vérifiez que:")
        print("  - Le lecteur RFID est bien connecté (SS=53, RST=5)")
        print("  - L'Arduino a le bon sketch uploadé")
        print("  - La carte RFID est compatible (MIFARE, UID)")
    
    ser.close()
    
except serial.SerialException as e:
    print(f"❌ Erreur de connexion: {e}")
    print("Vérifiez que:")
    print("  - L'Arduino est bien connecté sur COM6")
    print("  - Aucune autre application n'utilise le port")
except Exception as e:
    print(f"❌ Erreur: {e}")

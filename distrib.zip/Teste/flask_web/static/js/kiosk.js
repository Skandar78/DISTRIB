const API_ACTIVATE = '/activate_motor';
const API_STATUS = '/connection_status';

function el(selector) { return document.querySelector(selector); }

function showStatus(msg, kind='info'){
  const p = el('#statusMessage');
  if(!p) return;
  p.textContent = msg;
  p.className = 'status-message visible ' + (kind==='error'? 'error' : (kind==='success'? 'success' : ''));
}

async function sendActivate(slot){
  const btn = document.querySelector(`button[data-slot=\"${slot}\"]`);
  if(btn) btn.disabled = true;
  showStatus('Envoi commande...', 'info');
    try{
    const res = await fetch(API_ACTIVATE, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      // Do not send speed/seconds from the UI so server uses values from config.json
      body: JSON.stringify({ motor_id: slot })
    });
    const data = await res.json().catch(()=>({}));
    if(res.ok && data.ok){
      showStatus('Commande envoyée ✔', 'success');
    }else{
      showStatus(data.error || 'Erreur serveur', 'error');
    }
  }catch(err){
    showStatus('Erreur réseau: ' + err.message, 'error');
  }finally{
    setTimeout(()=>{ if(btn) btn.disabled = false; }, 2500);
  }
}

// Attach handlers to buttons
function wireButtons(){
  document.querySelectorAll('button[data-slot]').forEach(b=>{
    b.addEventListener('click', ()=>{
      const slot = parseInt(b.getAttribute('data-slot'));
      sendActivate(slot);
    });
  });
}

// Poll Arduino connection status and update banner
let lastConnected = null;
async function pollStatus(){
  try{
    const r = await fetch(API_STATUS);
    const j = await r.json();
    const connected = !!j.connected;
    const banner = el('#connStatus');
    if(connected !== lastConnected){
      // show change message
      if(connected){ showStatus('Arduino connecté', 'success'); }
      else { showStatus('Arduino déconnecté', 'error'); }
      lastConnected = connected;
    }
    if(banner) banner.textContent = connected? 'Connecté' : 'Déconnecté';
  }catch(e){
    const banner = el('#connStatus');
    if(banner) banner.textContent = 'Erreur';
  }
}

document.addEventListener('DOMContentLoaded', ()=>{
  wireButtons();
  wireDisconnect();
  pollStatus();
  setInterval(pollStatus, 3000);
});

// Wire disconnect button if present
function wireDisconnect(){
  const d = document.getElementById('disconnectBtn');
  if(!d) return;
  d.addEventListener('click', async ()=>{
    try{
      await fetch('/disconnect', { method: 'POST' });
    }catch(e){
      console.warn('Erreur disconnect', e);
    }
    // Redirect to home page
    window.location.href = '/';
  });
}

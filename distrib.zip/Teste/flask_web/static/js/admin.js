// admin.js - client-side wiring for admin page
let transactionsPage = 1;
let transactionsPageSize = 10;
let transactionsTotalCount = 0;

document.addEventListener('DOMContentLoaded', () => {
  loadProducts();
  loadUsers();
  loadTransactions();
  setInterval(loadTransactions, 15000);
  document.getElementById('saveNewCardBtn')?.addEventListener('click', saveNewCard);
  document.getElementById('saveUserBtn')?.addEventListener('click', saveEditedUser);
  document.getElementById('transactions-filters')?.addEventListener('submit', e => {
    e.preventDefault();
    transactionsPage = 1;
    loadTransactions();
  });
  document.getElementById('exportCsvBtn')?.addEventListener('click', exportTransactionsCsv);
  document.getElementById('resetFiltersBtn')?.addEventListener('click', resetTransactionFilters);
  
  // Filtres utilisateurs
  document.getElementById('users-filters')?.addEventListener('submit', e => {
    e.preventDefault();
    loadUsers();
  });
  document.getElementById('resetUsersFiltersBtn')?.addEventListener('click', resetUsersFilters);
  document.getElementById('exportUsersCsvBtn')?.addEventListener('click', exportUsersCsv);
  
  // Filtres produits
  document.getElementById('products-filters')?.addEventListener('submit', e => {
    e.preventDefault();
    loadProducts();
  });
  document.getElementById('resetProductsFiltersBtn')?.addEventListener('click', resetProductsFilters);
  document.getElementById('exportProductsCsvBtn')?.addEventListener('click', exportProductsCsv);
  // Relire / forcer une nouvelle lecture RFID depuis la modale (bouton ↻)
  const testRfidBtn = document.getElementById('testRfidBtn');
  if (testRfidBtn) {
    testRfidBtn.addEventListener('click', async () => {
      console.log('🔄 Bouton Relire RFID cliqué (admin.js)');
      const uidField = document.getElementById('newCardUid');
      if (uidField) {
        uidField.value = '';
        uidField.style.backgroundColor = '';
        uidField.style.borderColor = '';
      }
      try {
        const resp = await fetch('/trigger_rfid', { method: 'POST' });
        const data = await resp.json();
        console.log('📡 Trigger RFID response:', data);
        if (data.success) {
          alert('✅ Commande RFID envoyée à l\'Arduino.\n\nApprochez maintenant votre carte du lecteur.');
          // Attendre 2s puis lire
          setTimeout(async () => {
            try {
              const r = await fetch('/rfid_latest');
              const d = await r.json();
              console.log('📥 RFID latest:', d);
              if (d.uid && d.uid !== 'NONE') {
                if (uidField) {
                  uidField.value = d.uid;
                  uidField.style.backgroundColor = '#d4edda';
                }
                alert('✅ Carte détectée: ' + d.uid);
              } else {
                alert('❌ Aucune carte détectée.\n\nAssurez-vous qu\'une carte est proche du lecteur.');
              }
            } catch (e) {
              console.error('❌ Erreur lecture après trigger:', e);
              alert('❌ Erreur lecture RFID: ' + e);
            }
          }, 2000);
        } else {
          alert('❌ Erreur: ' + data.message);
        }
      } catch (error) {
        console.error('❌ Erreur:', error);
        alert('❌ Erreur de communication: ' + error);
      }
    });
  }

  // Universal modal close helper — ensures Cancel buttons always close modals
  function closeAllModals() {
    const modals = document.querySelectorAll('.modal.show');
    modals.forEach(modal => {
      modal.style.display = 'none';
      modal.classList.remove('show');
      modal.setAttribute('aria-hidden', 'true');
      modal.removeAttribute('aria-modal');
    });

    // remove all backdrops
    const backdrops = document.querySelectorAll('.modal-backdrop');
    backdrops.forEach(b => b.remove());
    document.body.classList.remove('modal-open');
    document.body.style.paddingRight = '';
    document.body.style.overflow = '';

    // Reset some form fields in case a modal was used for RFID
    const uidField = document.getElementById('newCardUid');
    if (uidField) {
      uidField.style.backgroundColor = '';
      uidField.style.borderColor = '';
      uidField.placeholder = 'Approchez la carte du lecteur RFID';
    }
  }

  // Delegated handler for data-bs-dismiss and 'Annuler' buttons to close modal reliably
  document.addEventListener('click', function (e) {
    const el = e.target.closest('[data-bs-dismiss="modal"], button.btn-secondary, button[aria-label="Close"]');
    // if clicked element or its closest ancestor is a modal dismiss button / cancel
    if (el) {
      // ensure we DO NOT intercept save buttons etc. Only handle explicit cancel/dismiss
      const text = (el.textContent||'').trim().toLowerCase();
      if (el.matches('[data-bs-dismiss="modal"]') || el.classList.contains('btn-secondary') || text === 'annuler') {
        // small delay ensures any other click handlers run first if needed
        setTimeout(() => closeAllModals(), 10);
      }
    }
  });
});

async function loadProducts(){
  try{
    const filters = getProductFilters();
    const r = await fetch('/products');
    const j = await r.json();
    const tbody = document.getElementById('products-table');
    if(!tbody) return;
    tbody.innerHTML = '';
    if(!j.success) return;
    
    // Appliquer les filtres côté client
    let products = j.products;
    if (filters.name) {
      products = products.filter(p => p.name.toLowerCase().includes(filters.name.toLowerCase()));
    }
    if (filters.maxPrice) {
      products = products.filter(p => p.price <= parseFloat(filters.maxPrice));
    }
    if (filters.minStock) {
      products = products.filter(p => p.stock >= parseInt(filters.minStock));
    }
    
    // Mettre à jour le compteur
    const countBadge = document.getElementById('products-count');
    if (countBadge) {
      countBadge.textContent = products.length;
    }
    
    products.forEach(p=>{
      const tr = document.createElement('tr');
      tr.dataset.productId = p.id;
      const thumb = p.has_image ? `<img src="${p.image_url}" class="rounded shadow-sm" style="width:70px;height:50px;object-fit:cover;border:2px solid #ddd;"/>` : '<span class="badge bg-secondary">Aucune image</span>';
      const stockClass = p.stock > 5 ? 'text-success' : p.stock > 0 ? 'text-warning' : 'text-danger';
      tr.innerHTML = `
        <td><span class="badge bg-secondary">${p.id}</span></td>
        <td><input class="form-control form-control-sm" data-field="name" value="${escapeHtml(p.name)}" placeholder="Nom du produit"></td>
        <td class="text-end">
          <div class="input-group input-group-sm">
            <input class="form-control text-end" type="number" data-field="price" step="0.01" min="0.01" value="${p.price}">
            <span class="input-group-text">€</span>
          </div>
        </td>
        <td class="text-center">
          <input class="form-control form-control-sm text-center ${stockClass} fw-bold" type="number" data-field="stock" value="${p.stock}" style="max-width:80px;margin:0 auto;">
        </td>
        <td>
          <div class="d-flex align-items-center gap-2">
            <label class="btn btn-outline-info btn-sm mb-0">
              <i class="bi bi-image-fill"></i> Choisir <input type="file" accept="image/*" data-field="image" style="display:none">
            </label>
            <button class="btn btn-info btn-sm upload-image"><i class="bi bi-cloud-upload"></i> Upload</button>
            <div class="ms-2">${thumb}</div>
          </div>
        </td>
        <td class="text-center"><button class="btn btn-success btn-sm save-product"><i class="bi bi-floppy"></i> Sauvegarder</button></td>
      `;
      tbody.appendChild(tr);
    });

    document.querySelectorAll('.save-product').forEach(b=>{
      b.addEventListener('click', async (e)=>{
        const tr = e.target.closest('tr');
        const id = parseInt(tr.dataset.productId);
        const name = tr.querySelector('[data-field="name"]').value;
        const price = parseFloat(tr.querySelector('[data-field="price"]').value);
        const stock = tr.querySelector('[data-field="stock"]').value;
        if(!(price > 0)) { alert('Le prix doit être strictement supérieur à 0'); return; }
        b.disabled = true;
        const resp = await fetch('/product_update', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id, name, price, stock})});
        const jj = await resp.json();
        if(jj.success){
          b.textContent = 'Sauvegardé';
          setTimeout(()=> b.textContent = 'Sauvegarder', 1200);
        } else {
          alert('Erreur: ' + (jj.message||''))
        }
        b.disabled = false;
      })
    })

    // Upload handlers
    document.querySelectorAll('.upload-image').forEach(btn=>{
      btn.addEventListener('click', async (e)=>{
        const tr = e.target.closest('tr');
        const id = parseInt(tr.dataset.productId);
        const fileInput = tr.querySelector('input[type="file"][data-field="image"]');
        if(!fileInput.files || !fileInput.files[0]){ alert('Choisissez une image'); return; }
        const fd = new FormData();
        fd.append('id', String(id));
        fd.append('file', fileInput.files[0]);
        btn.disabled = true;
        try{
          const r = await fetch('/product_image_upload', {method:'POST', body: fd});
          const j = await r.json();
          if(j.success){
            loadProducts();
          } else {
            alert('Erreur: ' + (j.message||''));
          }
        }catch(err){
          alert('Erreur réseau: ' + err);
        }finally{
          btn.disabled = false;
        }
      });
    });
  }catch(e){ console.warn('loadProducts', e) }
}

async function loadUsers(){
  try{
    const filters = getUserFilters();
    const r = await fetch('/users');
    if(!r.ok) return;
    const j = await r.json();
    if(!j.success) return;
    const tbody = document.getElementById('users-table');
    if(!tbody) return;
    tbody.innerHTML = '';
    
    // Appliquer les filtres côté client
    let users = j.users;
    if (filters.name) {
      const searchTerm = filters.name.toLowerCase();
      users = users.filter(u => 
        (u.first_name + ' ' + u.last_name).toLowerCase().includes(searchTerm) ||
        u.uid.toLowerCase().includes(searchTerm)
      );
    }
    if (filters.studentNumber) {
      users = users.filter(u => u.student_number && u.student_number.includes(filters.studentNumber));
    }
    if (filters.minBalance) {
      users = users.filter(u => u.balance >= parseFloat(filters.minBalance));
    }
    
    // Mettre à jour le compteur
    const countBadge = document.getElementById('users-count');
    if (countBadge) {
      countBadge.textContent = users.length;
    }
    
    users.forEach(u=>{
      const tr = document.createElement('tr');
      tr.dataset.userId = u.id;
      tr.dataset.studentNumber = u.student_number || '';
      const balance = (u.balance||0).toFixed(2);
      const balanceClass = balance >= 0 ? 'text-success fw-bold' : 'text-danger fw-bold';
      const fullName = `${(u.first_name||'').trim()} ${(u.last_name||'').trim()}`.trim() || 'Sans nom';
      tr.innerHTML = `
        <td><span class="badge bg-secondary">${u.id}</span></td>
        <td><i class="bi bi-person-circle text-success me-1"></i><strong>${escapeHtml(fullName)}</strong></td>
        <td><code class="bg-light px-2 py-1 rounded">${escapeHtml(u.uid)}</code></td>
        <td><span class="badge bg-primary">${escapeHtml(u.student_number||'—')}</span></td>
        <td class="text-end user-balance ${balanceClass}">${balance} €</td>
        <td><small class="text-muted"><i class="bi bi-clock me-1"></i>${u.last_seen||'Jamais'}</small></td>
        <td class="text-center">
          <div class="btn-group btn-group-sm">
            <button class="btn btn-outline-primary edit-user" title="Modifier"><i class="bi bi-pencil-square"></i></button>
            <button class="btn btn-outline-danger delete-user" title="Supprimer"><i class="bi bi-trash3"></i></button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    document.querySelectorAll('.edit-user').forEach(b=> b.addEventListener('click', e=> openEditUser(e)));
    document.querySelectorAll('.delete-user').forEach(b=> b.addEventListener('click', e=> deleteUser(e)));
  }catch(e){ console.warn('loadUsers', e) }
}

function openEditUser(e){
  const tr = e.target.closest('tr');
  const id = tr.dataset.userId;
  const student_number = tr.dataset.studentNumber || '';
  const cols = tr.children;
  const name = cols[1].textContent.trim().split(' ');
  const first = name.shift()||'';
  const last = name.join(' ')||'';
  // After adding the N° Étudiant column, the balance is now at index 4
  const balanceText = cols[4].textContent.replace(' €','').trim();
  document.getElementById('editFirstName').value = first;
  document.getElementById('editLastName').value = last;
  document.getElementById('editStudentNumber').value = student_number;
  document.getElementById('editBalance').value = parseFloat(balanceText)||0;
  document.getElementById('saveUserBtn').dataset.userId = id;
  
  // Ouvrir la modale manuellement (compatible avec custom modal handler)
  const modal = document.getElementById('editUserModal');
  if (modal) {
    modal.style.display = 'block';
    modal.classList.add('show');
    modal.setAttribute('aria-modal', 'true');
    modal.removeAttribute('aria-hidden');
    
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop fade show';
    backdrop.style.zIndex = '1040';
    document.body.appendChild(backdrop);
    document.body.classList.add('modal-open');
  }
}

async function saveEditedUser(){
  const id = this.dataset.userId || document.getElementById('saveUserBtn').dataset.userId;
  let first = document.getElementById('editFirstName').value.trim().toLowerCase();
  let last = document.getElementById('editLastName').value.trim().toLowerCase();
  const balance = parseFloat(document.getElementById('editBalance').value)||0;
  const student_number = document.getElementById('editStudentNumber').value.trim();
  
  // Validation: Prénom et nom obligatoires
  if(!first || !last){ 
    alert('Le prénom et le nom sont obligatoires'); 
    return;
  }
  
  try{
    const resp = await fetch('/register_user', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({uid:null, id: id, first_name:first, last_name:last, balance: balance, student_number: student_number || null})});
    const j = await resp.json();
    if(j.success){
      loadUsers();
      
      // Fermer la modale manuellement (compatible avec le custom modal handler)
      const modal = document.getElementById('editUserModal');
      if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
        modal.removeAttribute('aria-modal');
      }
      
      // Supprimer le backdrop
      const backdrops = document.querySelectorAll('.modal-backdrop');
      backdrops.forEach(backdrop => backdrop.remove());
      document.body.classList.remove('modal-open');
    } else {
      alert('Erreur: ' + (j.message||''))
    }
  }catch(e){ alert('Erreur réseau: ' + e) }
}

async function deleteUser(e){
  const tr = e.target.closest('tr');
  const id = tr.dataset.userId;
  if(!confirm('Supprimer cet utilisateur ?')) return;
  try{
    const resp = await fetch('/delete_user', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id})});
    const j = await resp.json();
    if(j.success){ loadUsers() } else alert('Erreur: ' + (j.message||''));
  }catch(e){ alert('Erreur réseau: ' + e) }
}

// New card registration flow
async function waitForScan(){
  // Ouvrir la modale manuellement (compatible avec custom modal handler)
  const modal = document.getElementById('newCardModal');
  if (modal) {
    // Réinitialiser les champs
    document.getElementById('newCardUid').value = '';
    document.getElementById('newCardFirstName').value = '';
    document.getElementById('newCardLastName').value = '';
    document.getElementById('newCardStudentNumber').value = '';
    document.getElementById('newCardBalance').value = '0';
    
    modal.style.display = 'block';
    modal.classList.add('show');
    modal.setAttribute('aria-modal', 'true');
    modal.removeAttribute('aria-hidden');
    
    // Ajouter backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop fade show';
    backdrop.style.zIndex = '1040';
    document.body.appendChild(backdrop);
    document.body.classList.add('modal-open');
  }
  
  // Message d'attente
  const uidField = document.getElementById('newCardUid');
  uidField.placeholder = 'En attente de la carte RFID...';
  
  console.log('🎯 waitForScan: Modale ouverte, appel de startRfidDetection...');
  
  // Démarrer la détection RFID (fonction définie dans admin.html)
  // Attendre que la fonction soit disponible (peut prendre un moment à charger)
  const tryStartDetection = (attempts = 0) => {
    if (typeof window.startRfidDetection === 'function') {
      console.log('✅ Fonction startRfidDetection trouvée, appel en cours...');
      window.startRfidDetection();
    } else if (attempts < 10) {
      console.warn(`⏳ Fonction startRfidDetection pas encore disponible, tentative ${attempts + 1}/10...`);
      setTimeout(() => tryStartDetection(attempts + 1), 100);
    } else {
      console.error('❌ Fonction startRfidDetection NON TROUVÉE après 10 tentatives !');
      alert('ERREUR: La fonction de détection RFID n\'est pas disponible !\n\nRechargez la page et réessayez.');
    }
  };
  
  tryStartDetection();
}

/* ---------- startRfidDetection (moved from admin.html) ---------- */
function startRfidDetection() {
  console.log('🔍 Démarrage détection RFID... (admin.js)');
  console.log('📍 Fonction startRfidDetection appelée depuis:', new Error().stack);

  const uidField = document.getElementById('newCardUid');
  if (!uidField) {
    console.error('❌ Champ newCardUid non trouvé');
    alert('❌ ERREUR: Champ UID introuvable !');
    return;
  }

  // debug observers & input listener
  const uidObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      console.log('🔍 Mutation détectée sur uidField:', mutation.type, mutation.attributeName);
    });
  });
  uidObserver.observe(uidField, {
    attributes: true,
    attributeOldValue: true,
    childList: true,
    characterData: true
  });

  uidField.addEventListener('input', function (e) {
    console.log('⌨️ Input event sur uidField - nouvelle valeur:', e.target.value);
  });

  // reset UI
  uidField.value = '';
  uidField.placeholder = 'En attente de carte RFID...';
  uidField.style.backgroundColor = '';
  uidField.style.borderColor = '';
  uidField.removeAttribute('readonly');

  const helpText = document.getElementById('uidHelpText');
  if (helpText) {
    helpText.textContent = 'Approchez la carte du lecteur RFID (ou saisissez manuellement)';
    helpText.style.color = '';
  }

  let pollCount = 0;
  console.log('📡 Envoi du trigger RFID...');

  fetch('/trigger_rfid', { method: 'POST' })
    .then(response => {
      console.log('📡 Réponse trigger RFID - Status:', response.status);
      return response.json();
    })
    .then(data => {
      console.log('🔄 Trigger RFID:', data);
      if (!data.success) {
        console.warn('⚠️ Trigger RFID échoué:', data.message);
        uidField.placeholder = 'Arduino non connecté - ' + (data.message || 'Vérifiez la connexion');
        uidField.style.backgroundColor = '#fff3cd';
        alert('⚠️ Arduino non connecté!\n\n' + data.message + '\n\nVous pouvez saisir l\'UID manuellement.');
      } else {
        console.log('✅ RFID réinitialisé et prêt pour nouvelle détection');
        uidField.placeholder = '📡 Lecteur RFID actif - Approchez votre carte...';
      }
    })
    .catch(error => {
      console.error('❌ Erreur trigger RFID:', error);
      alert('❌ Erreur trigger RFID: ' + error);
    });

  const rfidInterval = setInterval(() => {
    pollCount++;
    console.log(`🔄 Poll RFID #${pollCount}...`);

    fetch('/rfid_latest')
      .then(response => {
        if (!response.ok) {
          console.error('❌ Erreur HTTP:', response.status);
          return null;
        }
        return response.json();
      })
      .then(data => {
        if (!data) return;
        console.log('📥 Réponse RFID:', data);

        if (data.error) {
          console.warn('⚠️ Erreur Arduino:', data.error);
          uidField.placeholder = data.error + ' - Vérifiez la connexion';
          uidField.style.backgroundColor = '#fff3cd';
          uidField.style.borderColor = '#ffc107';
          return;
        }

        if (data.uid && data.uid !== 'NONE' && data.uid !== '' && data.uid !== null) {
          console.log('✅ Carte RFID détectée:', data.uid);
          console.log('📝 Tentative de remplissage du champ UID...');
          console.log('   - uidField:', uidField);
          console.log('   - uidField.value AVANT:', uidField.value);

          uidField.value = data.uid;

          // Safety: re-assign a few times if something else overwrites the value concurrently
          for (let i = 0; i < 4; i++) {
            setTimeout(() => {
              if (uidField.value !== data.uid) {
                console.warn('⚠️ UID champ modifié par autre code, rétablissement', {before: uidField.value, expected: data.uid});
                uidField.value = data.uid;
              }
            }, (i + 1) * 50);
          }

          console.log('   - uidField.value APRÈS:', uidField.value);
          console.log('   - Valeur assignée avec succès:', uidField.value === data.uid);

          uidField.placeholder = 'UID de la carte';
          uidField.style.backgroundColor = '#d4edda';
          uidField.style.borderColor = '#28a745';

          clearInterval(rfidInterval);
          console.log('⏹️ Détection RFID arrêtée');

          const helpText = document.getElementById('uidHelpText');
          if (helpText) {
            helpText.textContent = '✅ Carte détectée avec succès !';
            helpText.style.color = '#28a745';
            console.log('✅ Message d\'aide mis à jour');
          }

          const firstNameField = document.getElementById('newCardFirstName');
          if (firstNameField) {
            setTimeout(() => {
              firstNameField.focus();
              console.log('👆 Focus déplacé sur le champ prénom');
            }, 500);
          }
        } else {
          console.log('⏳ Aucune carte détectée pour le moment - data.uid:', data.uid);
        }
      })
      .catch(error => {
        console.error('❌ Erreur lecture RFID:', error);
      });
  }, 1000);

  uidField.addEventListener('input', function () {
    if (uidField.value.length > 0) {
      console.log('⌨️ Saisie manuelle détectée - arrêt de la détection auto');
      clearInterval(rfidInterval);
      uidField.style.backgroundColor = '#e7f3ff';
      uidField.style.borderColor = '#0d6efd';
      const helpText = document.getElementById('uidHelpText');
      if (helpText) {
        helpText.textContent = 'ℹ️ Saisie manuelle en cours';
        helpText.style.color = '#0d6efd';
      }
    }
  }, { once: true });

  const modal = document.getElementById('newCardModal');
  const stopDetection = () => {
    clearInterval(rfidInterval);
    console.log('🛑 Arrêt détection RFID');
  };

  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.attributeName === 'class' || mutation.attributeName === 'style') {
        if (!modal.classList.contains('show') || modal.style.display === 'none') {
          stopDetection();
          observer.disconnect();
        }
      }
    });
  });

  observer.observe(modal, { attributes: true });

  setTimeout(() => {
    stopDetection();
    if (uidField.value === '') {
      uidField.placeholder = 'Aucune carte détectée - Veuillez réessayer';
      uidField.style.backgroundColor = '#f8d7da';
      uidField.style.borderColor = '#dc3545';
    }
  }, 30000);
}

window.startRfidDetection = startRfidDetection;


async function saveNewCard(){
  const uid = document.getElementById('newCardUid').value.trim();
  let first = document.getElementById('newCardFirstName').value.trim().toLowerCase();
  let last = document.getElementById('newCardLastName').value.trim().toLowerCase();
  const balance = parseFloat(document.getElementById('newCardBalance').value)||0;
  const student_number = document.getElementById('newCardStudentNumber').value.trim();
  
  // Validation 1: UID obligatoire
  if(!uid){ 
    alert('UID manquant'); 
    return;
  }
  
  // Validation 2: Prénom et nom obligatoires
  if(!first || !last){ 
    alert('Le prénom et le nom sont obligatoires'); 
    return;
  }
  
  try{
    const r = await fetch('/register_user', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({uid, first_name:first, last_name:last, balance, student_number: student_number || null})});
    const j = await r.json();
    if(j.success){
      // Afficher le numéro étudiant généré
      if(j.student_number){
        alert(`✓ Carte enregistrée avec succès!\n\nNuméro étudiant généré: ${j.student_number}\n\nL'étudiant peut maintenant se connecter avec ce numéro.`);
      }
      
      // Fermer la modale manuellement (compatible avec le custom modal handler)
      const modal = document.getElementById('newCardModal');
      if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
        modal.removeAttribute('aria-modal');
      }
      
      // Supprimer le backdrop
      const backdrops = document.querySelectorAll('.modal-backdrop');
      backdrops.forEach(backdrop => backdrop.remove());
      document.body.classList.remove('modal-open');
      
      loadUsers();
    } else alert('Erreur: ' + (j.message||''));
  }catch(e){ alert('Erreur réseau: ' + e) }
}

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]) }

// Expose on window for inline buttons
window.loadProducts = loadProducts;
window.waitForScan = waitForScan;
window.loadUsers = loadUsers;
window.loadTransactions = loadTransactions;

async function loadTransactions(page = transactionsPage) {
  try {
    const filters = getTransactionFilters();
    const params = new URLSearchParams({
      page: page,
      page_size: transactionsPageSize
    });
    if (filters.user_uid) params.append('user_uid', filters.user_uid);
    if (filters.product_id) params.append('product_id', filters.product_id);
    if (filters.min_price) params.append('min_price', filters.min_price);
    if (filters.max_price) params.append('max_price', filters.max_price);
    if (filters.start_date) params.append('start_date', filters.start_date);
    if (filters.end_date) params.append('end_date', filters.end_date);

    const r = await fetch('/transactions?' + params.toString());
    const j = await r.json();
    const tbody = document.getElementById('transactions-table');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!j.success) return;
    transactionsTotalCount = j.total_count || 0;
    transactionsPage = j.page || 1;
    transactionsPageSize = j.page_size || 10;
    
    // Mettre à jour le compteur
    const countBadge = document.getElementById('transactions-count');
    if (countBadge) {
      countBadge.textContent = transactionsTotalCount;
    }
    
    j.transactions.forEach(t => {
      const tr = document.createElement('tr');
      const amount = (t.amount || 0).toFixed(2);
      const amountClass = amount < 0 ? 'text-danger fw-bold' : 'text-success fw-bold';
      const studentBadge = t.student_number ? `<span class="badge bg-secondary">${escapeHtml(t.student_number)}</span>` : '<span class="text-muted">—</span>';
      tr.innerHTML = `
        <td><i class="bi bi-person-circle text-primary me-1"></i>${escapeHtml(t.user_name || '')}</td>
        <td>${studentBadge}</td>
        <td><span class="badge bg-info">${escapeHtml(t.product_name || '—')}</span></td>
        <td class="text-end ${amountClass}">${amount} €</td>
        <td><small class="text-muted"><i class="bi bi-calendar-event me-1"></i>${escapeHtml(t.ts || '')}</small></td>
      `;
      tbody.appendChild(tr);
    });
    updateTransactionsPagination();
  } catch (e) { console.warn('loadTransactions', e); }
}

function resetTransactionFilters() {
  document.getElementById('filterUser').value = '';
  document.getElementById('filterProduct').value = '';
  document.getElementById('filterMinPrice').value = '';
  document.getElementById('filterMaxPrice').value = '';
  document.getElementById('filterStartDate').value = '';
  document.getElementById('filterEndDate').value = '';
  transactionsPage = 1;
  loadTransactions();
}

function getTransactionFilters() {
  return {
    user_uid: document.getElementById('filterUser')?.value.trim() || '',
    product_id: document.getElementById('filterProduct')?.value.trim() || '',
    min_price: document.getElementById('filterMinPrice')?.value.trim() || '',
    max_price: document.getElementById('filterMaxPrice')?.value.trim() || '',
    start_date: document.getElementById('filterStartDate')?.value.trim() || '',
    end_date: document.getElementById('filterEndDate')?.value.trim() || ''
  };
}

function updateTransactionsPagination() {
  const pag = document.getElementById('transactions-pagination');
  if (!pag) return;
  pag.innerHTML = '';
  const totalPages = Math.ceil(transactionsTotalCount / transactionsPageSize);
  if (totalPages <= 1) return;

  // Bouton Précédent
  const prevLi = document.createElement('li');
  prevLi.className = 'page-item' + (transactionsPage === 1 ? ' disabled' : '');
  const prevA = document.createElement('a');
  prevA.className = 'page-link';
  prevA.textContent = '‹ Précédent';
  prevA.href = '#';
  if (transactionsPage > 1) {
    prevA.addEventListener('click', e => {
      e.preventDefault();
      transactionsPage--;
      loadTransactions(transactionsPage);
    });
  }
  prevLi.appendChild(prevA);
  pag.appendChild(prevLi);

  // Afficher max 10 boutons de page
  let startPage = Math.max(1, transactionsPage - 5);
  let endPage = Math.min(totalPages, startPage + 9);
  if (endPage - startPage < 9) {
    startPage = Math.max(1, endPage - 9);
  }

  // Première page si pas visible
  if (startPage > 1) {
    const li = document.createElement('li');
    li.className = 'page-item';
    const a = document.createElement('a');
    a.className = 'page-link';
    a.textContent = '1';
    a.href = '#';
    a.addEventListener('click', e => {
      e.preventDefault();
      transactionsPage = 1;
      loadTransactions(1);
    });
    li.appendChild(a);
    pag.appendChild(li);
    
    if (startPage > 2) {
      const dots = document.createElement('li');
      dots.className = 'page-item disabled';
      dots.innerHTML = '<span class="page-link">...</span>';
      pag.appendChild(dots);
    }
  }

  // Boutons de pages
  for (let i = startPage; i <= endPage; i++) {
    const li = document.createElement('li');
    li.className = 'page-item' + (i === transactionsPage ? ' active' : '');
    const a = document.createElement('a');
    a.className = 'page-link';
    a.textContent = i;
    a.href = '#';
    a.addEventListener('click', e => {
      e.preventDefault();
      transactionsPage = i;
      loadTransactions(i);
    });
    li.appendChild(a);
    pag.appendChild(li);
  }

  // Dernière page si pas visible
  if (endPage < totalPages) {
    if (endPage < totalPages - 1) {
      const dots = document.createElement('li');
      dots.className = 'page-item disabled';
      dots.innerHTML = '<span class="page-link">...</span>';
      pag.appendChild(dots);
    }
    
    const li = document.createElement('li');
    li.className = 'page-item';
    const a = document.createElement('a');
    a.className = 'page-link';
    a.textContent = totalPages;
    a.href = '#';
    a.addEventListener('click', e => {
      e.preventDefault();
      transactionsPage = totalPages;
      loadTransactions(totalPages);
    });
    li.appendChild(a);
    pag.appendChild(li);
  }

  // Bouton Suivant
  const nextLi = document.createElement('li');
  nextLi.className = 'page-item' + (transactionsPage === totalPages ? ' disabled' : '');
  const nextA = document.createElement('a');
  nextA.className = 'page-link';
  nextA.textContent = 'Suivant ›';
  nextA.href = '#';
  if (transactionsPage < totalPages) {
    nextA.addEventListener('click', e => {
      e.preventDefault();
      transactionsPage++;
      loadTransactions(transactionsPage);
    });
  }
  nextLi.appendChild(nextA);
  pag.appendChild(nextLi);
}

async function exportTransactionsCsv() {
  const filters = getTransactionFilters();
  const params = new URLSearchParams();
  if (filters.user_uid) params.append('user_uid', filters.user_uid);
  if (filters.product_id) params.append('product_id', filters.product_id);
  if (filters.min_price) params.append('min_price', filters.min_price);
  if (filters.max_price) params.append('max_price', filters.max_price);
  if (filters.start_date) params.append('start_date', filters.start_date);
  if (filters.end_date) params.append('end_date', filters.end_date);
  window.open('/transactions/export?' + params.toString(), '_blank');
}

// Filtres utilisateurs
function getUserFilters() {
  return {
    name: document.getElementById('filterUserName')?.value.trim() || '',
    studentNumber: document.getElementById('filterStudentNumber')?.value.trim() || '',
    minBalance: document.getElementById('filterMinBalance')?.value.trim() || ''
  };
}

function resetUsersFilters() {
  document.getElementById('filterUserName').value = '';
  document.getElementById('filterStudentNumber').value = '';
  document.getElementById('filterMinBalance').value = '';
  loadUsers();
}

async function exportUsersCsv() {
  try {
    const r = await fetch('/users');
    const j = await r.json();
    if (!j.success) return;
    
    const filters = getUserFilters();
    let users = j.users;
    
    // Appliquer les mêmes filtres
    if (filters.name) {
      const searchTerm = filters.name.toLowerCase();
      users = users.filter(u => 
        (u.first_name + ' ' + u.last_name).toLowerCase().includes(searchTerm) ||
        u.uid.toLowerCase().includes(searchTerm)
      );
    }
    if (filters.studentNumber) {
      users = users.filter(u => u.student_number && u.student_number.includes(filters.studentNumber));
    }
    if (filters.minBalance) {
      users = users.filter(u => u.balance >= parseFloat(filters.minBalance));
    }
    
    // Créer le CSV
    let csv = 'ID,Nom,Prénom,UID RFID,Numéro Étudiant,Solde,Dernière visite\n';
    users.forEach(u => {
      csv += `${u.id},"${u.last_name || ''}","${u.first_name || ''}","${u.uid}","${u.student_number || ''}",${u.balance || 0},"${u.last_seen || 'Jamais'}"\n`;
    });
    
    // Télécharger
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'utilisateurs.csv';
    link.click();
  } catch (e) {
    console.error('Export users CSV error:', e);
  }
}

// Filtres produits
function getProductFilters() {
  return {
    name: document.getElementById('filterProductName')?.value.trim() || '',
    maxPrice: document.getElementById('filterMaxProductPrice')?.value.trim() || '',
    minStock: document.getElementById('filterMinStock')?.value.trim() || ''
  };
}

function resetProductsFilters() {
  document.getElementById('filterProductName').value = '';
  document.getElementById('filterMaxProductPrice').value = '';
  document.getElementById('filterMinStock').value = '';
  loadProducts();
}

async function exportProductsCsv() {
  try {
    const r = await fetch('/products');
    const j = await r.json();
    if (!j.success) return;
    
    const filters = getProductFilters();
    let products = j.products;
    
    // Appliquer les mêmes filtres
    if (filters.name) {
      products = products.filter(p => p.name.toLowerCase().includes(filters.name.toLowerCase()));
    }
    if (filters.maxPrice) {
      products = products.filter(p => p.price <= parseFloat(filters.maxPrice));
    }
    if (filters.minStock) {
      products = products.filter(p => p.stock >= parseInt(filters.minStock));
    }
    
    // Créer le CSV
    let csv = 'ID,Nom du Produit,Prix (€),Stock,Image\n';
    products.forEach(p => {
      csv += `${p.id},"${p.name}",${p.price},${p.stock},"${p.has_image ? 'Oui' : 'Non'}"\n`;
    });
    
    // Télécharger
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'produits.csv';
    link.click();
  } catch (e) {
    console.error('Export products CSV error:', e);
  }
}

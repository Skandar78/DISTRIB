import sqlite3
import os

db_path = os.path.join(os.path.dirname(__file__), 'distributor.db')
print(f"Vérification de la base de données: {db_path}")
print(f"Fichier existe: {os.path.exists(db_path)}")

if os.path.exists(db_path):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    
    # Vérifier les tables
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cur.fetchall()
    print(f"\nTables trouvées: {[t[0] for t in tables]}")
    
    # Vérifier les produits
    cur.execute("SELECT * FROM products")
    products = cur.fetchall()
    print(f"\nProduits ({len(products)}):")
    for p in products:
        print(f"  - ID:{p[0]}, Nom:{p[1]}, Stock:{p[2]}, Prix:{p[3]}€")
    
    # Vérifier les utilisateurs
    cur.execute("SELECT * FROM users")
    users = cur.fetchall()
    print(f"\nUtilisateurs ({len(users)}):")
    for u in users:
        print(f"  - ID:{u[0]}, UID:{u[1]}, Nom:{u[5]} {u[6]}, Balance:{u[7]}€")
    
    conn.close()
    print("\n✅ Base de données SQLite fonctionnelle !")

import sqlite3
import os

# Chemin vers la base de données
db_path = os.path.join(os.path.dirname(__file__), 'distributor.db')

print("=== Création d'un utilisateur de test ===")

if not os.path.exists(db_path):
    print(f"❌ Base de données introuvable: {db_path}")
    exit(1)

conn = sqlite3.connect(db_path)
cur = conn.cursor()

# Créer un utilisateur de test
test_uid = "TEST123ABC"
first_name = "Jean"
last_name = "Dupont"
balance = 10.00

cur.execute("SELECT id FROM users WHERE uid=?", (test_uid,))
existing = cur.fetchone()

if existing:
    print(f"Utilisateur {test_uid} existe déjà, mise à jour...")
    cur.execute("UPDATE users SET first_name=?, last_name=?, balance=? WHERE uid=?",
                (first_name, last_name, balance, test_uid))
else:
    print(f"Création nouvel utilisateur...")
    import datetime
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cur.execute("INSERT INTO users (uid, first_name, last_name, balance, first_seen, last_seen, hits) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (test_uid, first_name, last_name, balance, now, now, 0))

conn.commit()
conn.close()

print(f"\n✅ Utilisateur de test créé!")
print(f"UID: {test_uid}")
print(f"Nom: {first_name} {last_name}")
print(f"Solde: {balance}€")
print(f"\nPour tester:")
print(f"1. Allez sur http://localhost:5000")
print(f"2. Dans la console navigateur, exécutez:")
print(f"   fetch('/trigger_rfid', {{method:'POST', headers:{{'Content-Type':'application/json'}}, body:JSON.stringify({{uid:'{test_uid}'}})}}).then(r=>r.json()).then(console.log)")
print(f"3. Ou allez directement sur: http://localhost:5000/student?uid={test_uid}")

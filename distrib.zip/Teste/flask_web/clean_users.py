import sqlite3
import json

# Charger la config
with open('config.json') as f:
    config = json.load(f)

db_file = config.get('db_file', 'distributor.db')

# Se connecter à la base de données
conn = sqlite3.connect(db_file)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

print("=== NETTOYAGE DES UTILISATEURS SANS NOM/PRÉNOM ===\n")

# Compter les utilisateurs sans nom/prénom
cur.execute('SELECT COUNT(*) as count FROM users WHERE first_name IS NULL OR last_name IS NULL OR first_name = "" OR last_name = ""')
count = cur.fetchone()['count']

if count == 0:
    print("✅ Aucun utilisateur sans nom/prénom trouvé.")
else:
    print(f"⚠️  {count} utilisateur(s) sans nom/prénom trouvé(s).\n")
    
    # Afficher les utilisateurs qui seront supprimés
    cur.execute('SELECT id, uid FROM users WHERE first_name IS NULL OR last_name IS NULL OR first_name = "" OR last_name = ""')
    rows = cur.fetchall()
    
    print("Les utilisateurs suivants seront SUPPRIMÉS :")
    for row in rows:
        print(f"  - ID: {row['id']}, UID: {row['uid']}")
    
    # Demander confirmation
    response = input("\n⚠️  Voulez-vous supprimer ces utilisateurs? (oui/non): ")
    
    if response.lower() in ['oui', 'o', 'yes', 'y']:
        cur.execute('DELETE FROM users WHERE first_name IS NULL OR last_name IS NULL OR first_name = "" OR last_name = ""')
        conn.commit()
        print(f"\n✅ {count} utilisateur(s) supprimé(s).")
    else:
        print("\n❌ Annulé. Aucune modification effectuée.")

# Afficher les utilisateurs restants
print("\n=== UTILISATEURS RESTANTS ===\n")
cur.execute('SELECT id, uid, first_name, last_name, balance FROM users')
rows = cur.fetchall()

if not rows:
    print("Aucun utilisateur dans la base de données.")
else:
    for row in rows:
        print(f"ID: {row['id']}")
        print(f"UID: {row['uid']}")
        print(f"Prénom: {row['first_name']}")
        print(f"Nom: {row['last_name']}")
        print(f"Solde: {row['balance']} €")
        print("-" * 40)

conn.close()

#!/usr/bin/env python3
"""
Script de détection automatique du port série Arduino sur Linux
"""

import serial.tools.list_ports
import json
import os

def detect_arduino_port():
    """Détecte automatiquement le port Arduino"""
    ports = serial.tools.list_ports.comports()
    
    # Ports typiques Arduino sur Linux
    arduino_ports = []
    
    for port in ports:
        port_name = port.device
        description = port.description.lower()
        
        # Critères de détection Arduino
        if any(keyword in description for keyword in ['arduino', 'ch340', 'cp210x', 'ftdi', 'usb']):
            arduino_ports.append({
                'port': port_name,
                'description': port.description,
                'vid_pid': f"{port.vid:04x}:{port.pid:04x}" if port.vid and port.pid else "unknown"
            })
    
    return arduino_ports

def update_config_port(new_port):
    """Met à jour le port dans config.json"""
    config_path = os.path.join(os.path.dirname(__file__), 'config.json')
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        config['com_port'] = new_port
        
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Port mis à jour dans config.json: {new_port}")
        return True
    except Exception as e:
        print(f"❌ Erreur mise à jour config: {e}")
        return False

def main():
    print("🔍 Détection des ports série Arduino...")
    
    arduino_ports = detect_arduino_port()
    
    if not arduino_ports:
        print("❌ Aucun Arduino détecté!")
        print("Vérifiez que:")
        print("- L'Arduino est connecté via USB")
        print("- Les drivers sont installés")
        print("- Vous avez les permissions (ajoutez-vous au groupe dialout)")
        return
    
    print(f"✅ {len(arduino_ports)} Arduino(s) détecté(s):")
    
    for i, port_info in enumerate(arduino_ports):
        print(f"  {i+1}. {port_info['port']} - {port_info['description']} ({port_info['vid_pid']})")
    
    if len(arduino_ports) == 1:
        # Un seul Arduino, mise à jour automatique
        chosen_port = arduino_ports[0]['port']
        print(f"🔧 Mise à jour automatique avec: {chosen_port}")
        update_config_port(chosen_port)
    else:
        # Plusieurs Arduino, demander à l'utilisateur
        try:
            choice = input(f"\nChoisissez le port (1-{len(arduino_ports)}): ")
            choice_idx = int(choice) - 1
            
            if 0 <= choice_idx < len(arduino_ports):
                chosen_port = arduino_ports[choice_idx]['port']
                print(f"🔧 Mise à jour avec: {chosen_port}")
                update_config_port(chosen_port)
            else:
                print("❌ Choix invalide!")
        except (ValueError, KeyboardInterrupt):
            print("❌ Annulé!")

if __name__ == "__main__":
    main()
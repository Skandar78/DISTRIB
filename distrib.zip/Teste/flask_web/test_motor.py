#!/usr/bin/env python3
"""
Script de diagnostic pour tester la connexion série et les moteurs
"""
import serial
import serial.tools.list_ports as list_ports
import time
import json
import os

def load_config():
    """Charge la configuration"""
    config_path = os.path.join(os.path.dirname(__file__), 'config.json')
    with open(config_path, 'r') as f:
        return json.load(f)

def list_available_ports():
    """Liste tous les ports série disponibles"""
    print("\n=== PORTS SÉRIE DISPONIBLES ===")
    ports = list(list_ports.comports())
    if not ports:
        print("❌ Aucun port série trouvé")
        return []
    
    for port in ports:
        print(f"✓ {port.device} - {port.description}")
    print("================================\n")
    return [port.device for port in ports]

def test_serial_connection(port, baudrate=9600):
    """Teste la connexion série"""
    print(f"\n🔌 Test de connexion à {port} @ {baudrate} bauds...")
    
    try:
        # Vérifier si le port existe
        if not os.path.exists(port):
            print(f"❌ Le port {port} n'existe pas sur le système")
            return False
        
        # Tenter la connexion
        ser = serial.Serial(
            port=port,
            baudrate=baudrate,
            timeout=1,
            write_timeout=1
        )
        
        print(f"✅ Connexion réussie!")
        print(f"   - Port: {ser.port}")
        print(f"   - Baudrate: {ser.baudrate}")
        print(f"   - Timeout: {ser.timeout}s")
        print(f"   - Ouvert: {ser.is_open}")
        
        # Attendre que l'Arduino se réinitialise
        print("⏳ Attente de l'initialisation Arduino (2s)...")
        time.sleep(2)
        
        # Vider le buffer
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        
        # Tester l'envoi d'une commande
        print("\n📤 Envoi d'une commande de test: 'move 1 1002 2000'")
        command = "move 1 1002 2000\n"
        ser.write(command.encode())
        ser.flush()
        print("✅ Commande envoyée")
        
        # Lire la réponse pendant 3 secondes
        print("\n📥 Lecture des réponses Arduino (3s)...")
        start = time.time()
        while time.time() - start < 3:
            if ser.in_waiting > 0:
                line = ser.readline().decode('utf-8', errors='ignore').strip()
                if line:
                    print(f"   Arduino: {line}")
            time.sleep(0.1)
        
        ser.close()
        print("\n✅ Test terminé avec succès")
        return True
        
    except PermissionError as e:
        print(f"❌ ERREUR: Permission refusée")
        print(f"   Sur Linux, ajoutez votre utilisateur au groupe dialout:")
        print(f"   sudo usermod -a -G dialout $USER")
        print(f"   Puis déconnectez-vous et reconnectez-vous")
        return False
        
    except serial.SerialException as e:
        print(f"❌ ERREUR série: {e}")
        return False
        
    except Exception as e:
        print(f"❌ ERREUR: {e}")
        return False

def main():
    print("🔧 DIAGNOSTIC MOTEUR RFID DISTRIBUTOR")
    print("=" * 50)
    
    # Charger la config
    try:
        config = load_config()
        configured_port = config.get('com_port', 'COM6')
        baudrate = config.get('baudrate', 9600)
        print(f"\n📋 Configuration:")
        print(f"   Port configuré: {configured_port}")
        print(f"   Baudrate: {baudrate}")
    except Exception as e:
        print(f"❌ Erreur lecture config.json: {e}")
        return
    
    # Lister les ports disponibles
    available_ports = list_available_ports()
    
    # Tester la connexion au port configuré
    if configured_port in available_ports:
        print(f"✅ Le port configuré {configured_port} est disponible")
        test_serial_connection(configured_port, baudrate)
    else:
        print(f"❌ Le port configuré {configured_port} n'est pas disponible")
        if available_ports:
            print(f"\n💡 Suggestion: Utilisez un des ports disponibles:")
            for port in available_ports:
                print(f"   - {port}")
            
            # Tester le premier port disponible
            print(f"\n🔍 Test du premier port disponible: {available_ports[0]}")
            if test_serial_connection(available_ports[0], baudrate):
                print(f"\n💡 Mettez à jour config.json avec:")
                print(f'   "com_port": "{available_ports[0]}"')

if __name__ == '__main__':
    main()

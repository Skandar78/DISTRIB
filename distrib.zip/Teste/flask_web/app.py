
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, Response
import serial
import threading
import queue
import time
import os
from serial.tools import list_ports
import json
import sqlite3
import datetime
from io import StringIO
import importlib.util
import requests
import csv

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Clé secrète pour les sessions

# Endpoint pour vérifier l'état Arduino
@app.route('/arduino_status')
def arduino_status():
    return jsonify({'connected': motor_controller.connected})

# Load config from flask_web/config.json
CONFIG = {
    'com_port': os.environ.get('COM_PORT', 'COM6'),
    'baudrate': int(os.environ.get('BAUD_RATE', 9600)),
    'default_speed': 512,
    'default_seconds': 5,
    'db_file': 'distributor.db'
}
config_path = os.path.join(os.path.dirname(__file__), 'config.json')
if os.path.exists(config_path):
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
            CONFIG.update(cfg)
            CONFIG['baudrate'] = int(CONFIG.get('baudrate', CONFIG['baudrate']))
            CONFIG['default_speed'] = int(CONFIG.get('default_speed', CONFIG['default_speed']))
            CONFIG['default_seconds'] = float(CONFIG.get('default_seconds', CONFIG['default_seconds']))
    except Exception as e:
        print(f"[WARN] Impossible de lire config.json: {e}")
else:
    print(f"[INFO] Aucun config.json trouvé")

class MotorController:
    def __init__(self, port=None, baudrate=9600):
        self.port = port or CONFIG.get('com_port', 'COM6')
        self.baudrate = CONFIG.get('baudrate', baudrate)
        self.serial = None
        self.tx_queue = queue.Queue()
        self.last_rfid = None
        self.last_rfid_time = None
        self.connected = False
        self._tx_thread = None
        self.db_conn = None
        self.db_cursor = None

    def get_system_info(self):
        """Retourne les informations système"""
        import platform
        return f"{platform.system()} {platform.release()}"

    def list_ports(self):
        """Liste tous les ports série disponibles"""
        return [port.device for port in list_ports.comports()]

    def connect(self):
        try:
            if self.connected:
                print("[INFO] Déjà connecté")
                return True
            print(f"[INFO] Tentative de connexion au port {self.port} à {self.baudrate} bauds")
            
            # Vérifier si le port existe
            if not os.path.exists(self.port):
                print(f"[ERROR] Le port {self.port} n'existe pas")
                available_ports = [port.device for port in list_ports.comports()]
                print(f"[INFO] Ports disponibles: {available_ports}")
                self.connected = False
                return False
            
            self.serial = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=0.1,
                write_timeout=1
            )
            time.sleep(2)
            self.connected = True
            self._start_tx_thread()
            print("[SUCCESS] Connexion réussie!")
            return True
        except PermissionError as e:
            print(f"[ERROR] Permission refusée pour {self.port}")
            print(f"[SUGGESTION] Ajoutez votre utilisateur au groupe dialout: sudo usermod -a -G dialout $USER")
            print(f"[SUGGESTION] Puis redémarrez la session")
            self.connected = False
            return False
        except serial.SerialException as e:
            print(f"[ERROR] Erreur de connexion série: {e}")
            print(f"[DEBUG] Type d'erreur: {type(e).__name__}")
            print(f"[DEBUG] Message détaillé: {str(e)}")
            self.connected = False
            return False
        except Exception as e:
            print(f"[ERROR] Échec de la connexion: {e}")
            print(f"[DEBUG] Type d'erreur: {type(e).__name__}")
            print(f"[DEBUG] Message détaillé: {str(e)}")
            self.connected = False
            return False

    def _start_tx_thread(self):
        if not self._tx_thread or not self._tx_thread.is_alive():
            self._tx_thread = threading.Thread(target=self._tx_worker, daemon=True)
            self._tx_thread.start()

    def _tx_worker(self):
        """Thread qui gère la transmission série et la lecture RFID"""
        print("[DEBUG] Thread TX démarré")
        while self.connected and self.serial and self.serial.is_open:
            try:
                # Lire les données série (RFID)
                if self.serial.in_waiting > 0:
                    line = self.serial.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        print(f"[RX] {line}")
                        if line.startswith('RFID:'):
                            uid = line.split(':',1)[1].strip()
                            # Ignorer les timeouts
                            if uid and uid != 'TIMEOUT':
                                self.last_rfid = uid
                                self.last_rfid_time = time.time()
                                print(f"[RFID] UID détecté: {uid}")
                                self._store_rfid(uid)
                            elif uid == 'TIMEOUT':
                                print(f"[RFID] Timeout - aucune carte détectée")
                
                # Envoyer les commandes en attente
                try:
                    cmd = self.tx_queue.get(timeout=0.05)
                    if cmd:
                        self.serial.write((cmd + '\n').encode())
                        print(f"[TX] Envoyé: {cmd}")
                        self.serial.flush()
                except queue.Empty:
                    pass
            except Exception as e:
                print(f"[ERROR] Erreur dans _tx_worker: {e}")
                time.sleep(0.1)

    def send_command(self, motor_id, seconds, speed):
        """
        Envoie une commande de mouvement au moteur
        Format: move <id> <speed> <time_ms>
        """
        try:
            if not self.connected or not self.serial or not self.serial.is_open:
                print("[WARN] Port série non connecté")
                return False
            
            time_ms = int(seconds * 1000)
            command = f"move {motor_id} {speed} {time_ms}"
            print(f"[MOTOR] Commande: {command}")
            self.tx_queue.put(command)
            return True
        except Exception as e:
            print(f"[ERROR] Erreur send_command: {e}")
            return False

    def disconnect(self):
        """Ferme la connexion série"""
        print("[INFO] Déconnexion en cours...")
        self.connected = False
        if self._tx_thread and self._tx_thread.is_alive():
            self._tx_thread.join(timeout=2)
        if self.serial and self.serial.is_open:
            self.serial.close()
        print("[INFO] Déconnecté")
        if self.db_conn:
            try:
                self.db_conn.close()
            except:
                pass
            self.db_conn = None
            self.db_cursor = None

    # --- Database helpers ---
    def _get_db_conn(self):
        """Crée une connexion SQLite à la base de données"""
        if self.db_conn:
            return self.db_conn
        
        try:
            db_file = os.path.join(os.path.dirname(__file__), CONFIG.get('db_file', 'distributor.db'))
            self.db_conn = sqlite3.connect(db_file, check_same_thread=False)
            self.db_conn.row_factory = sqlite3.Row
            self.db_cursor = self.db_conn.cursor()
            return self.db_conn
        except Exception as err:
            print(f"[DB] Erreur connexion SQLite: {err}")
            self.db_conn = None
            self.db_cursor = None
            raise

    def _generate_student_number(self):
        """Génère un numéro étudiant unique au format ETU-YYYYXXXX"""
        import random
        conn = self._get_db_conn()
        cur = conn.cursor()
        year = datetime.datetime.now().year
        
        # Essayer jusqu'à trouver un numéro unique
        for _ in range(100):
            num = random.randint(1000, 9999)
            student_number = f"ETU-{year}{num}"
            cur.execute("SELECT id FROM users WHERE student_number = ?", (student_number,))
            if not cur.fetchone():
                return student_number
        
        # Fallback avec timestamp si collision après 100 essais
        return f"ETU-{year}{int(time.time()) % 10000}"
    
    def _generate_missing_student_numbers(self):
        """Génère automatiquement des numéros étudiants pour tous les utilisateurs qui n'en ont pas"""
        try:
            conn = self._get_db_conn()
            cur = conn.cursor()
            
            # Trouver tous les utilisateurs sans numéro étudiant
            cur.execute("SELECT id FROM users WHERE student_number IS NULL OR student_number = ''")
            users_without_number = cur.fetchall()
            
            if users_without_number:
                print(f"[DB] Génération de {len(users_without_number)} numéros étudiants...")
                for row in users_without_number:
                    user_id = row[0]
                    new_number = self._generate_student_number()
                    cur.execute("UPDATE users SET student_number = ? WHERE id = ?", (new_number, user_id))
                    print(f"[DB] Utilisateur #{user_id} -> {new_number}")
                
                conn.commit()
                print(f"[DB] ✓ {len(users_without_number)} numéros étudiants générés")
        except Exception as e:
            print(f"[DB] Erreur génération numéros étudiants: {e}")

    def init_db(self):
        """Crée les tables si elles n'existent pas"""
        try:
            conn = self._get_db_conn()
            cur = conn.cursor()
            
            # Table users
            cur.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    uid TEXT NOT NULL UNIQUE,
                    first_seen TEXT,
                    last_seen TEXT,
                    hits INTEGER DEFAULT 0,
                    first_name TEXT,
                    last_name TEXT,
                    balance REAL DEFAULT 0.0,
                    student_number TEXT UNIQUE
                )
            """)
            
            # Ajouter colonne student_number si manquante (sans UNIQUE au début)
            try:
                cur.execute("PRAGMA table_info(users)")
                cols = [r[1] for r in cur.fetchall()]
                if 'student_number' not in cols:
                    # Ajouter la colonne sans contrainte UNIQUE d'abord
                    cur.execute("ALTER TABLE users ADD COLUMN student_number TEXT")
                    conn.commit()
                    print("[DB] Colonne student_number ajoutée")
            except Exception as e:
                print(f"[DB] Unable to add student_number column (may already exist): {e}")
            
            # Table rfid_reads
            cur.execute("""
                CREATE TABLE IF NOT EXISTS rfid_reads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    uid TEXT,
                    ts TEXT
                )
            """)
            
            # Table products
            cur.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY,
                    name TEXT,
                    stock INTEGER DEFAULT 0,
                    price REAL DEFAULT 0.0
                )
            """)
            
            # Ajouter colonnes image si manquantes
            try:
                cur.execute("PRAGMA table_info(products)")
                cols = [r[1] for r in cur.fetchall()]
                if 'image_blob' not in cols:
                    cur.execute("ALTER TABLE products ADD COLUMN image_blob BLOB")
                if 'image_mime' not in cols:
                    cur.execute("ALTER TABLE products ADD COLUMN image_mime TEXT")
            except Exception as e:
                print(f"[DB] Unable to add image columns (may already exist): {e}")

            # Table transactions
            cur.execute("""
                CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    product_id INTEGER,
                    amount REAL,
                    description TEXT,
                    ts TEXT
                )
            """)

            conn.commit()
            
            # Seed 4 produits
            for pid in range(1, 5):
                cur.execute("INSERT OR IGNORE INTO products (id, name, stock, price) VALUES (?, ?, ?, ?)", 
                           (pid, f'Produit {pid}', 10, 1.00))
            conn.commit()
            
            # Générer automatiquement des numéros étudiants pour les comptes existants
            self._generate_missing_student_numbers()
            
            # Créer un index UNIQUE pour garantir l'unicité côté base
            try:
                cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_student_number ON users(student_number)")
                conn.commit()
            except Exception as e:
                print(f"[DB] Impossible de créer l'index unique sur student_number: {e}")
            
            print("[DB] Tables créées/vérifiées")
        except Exception as e:
            print(f"[DB] Erreur init_db: {e}")

    def _store_rfid(self, uid):
        """Enregistre la lecture RFID dans la DB"""
        try:
            conn = self._get_db_conn()
            cur = conn.cursor()
            now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            # Enregistrer uniquement la lecture RFID
            cur.execute("INSERT INTO rfid_reads (uid, ts) VALUES (?, ?)", (uid, now))
            
            # Mettre à jour SEULEMENT si l'utilisateur existe déjà
            cur.execute("SELECT id FROM users WHERE uid=?", (uid,))
            row = cur.fetchone()
            if row:
                cur.execute("UPDATE users SET last_seen=?, hits=hits+1 WHERE uid=?", (now, uid))
            # Ne plus créer automatiquement un utilisateur si la carte n'existe pas
            
            conn.commit()
        except Exception as e:
            print(f"[DB] Erreur _store_rfid: {e}")

# Instance globale
motor_controller = MotorController(
    port=CONFIG.get('com_port'),
    baudrate=CONFIG.get('baudrate', 9600)
)

# Routes Flask
@app.route('/')
def index():
    return render_template(
        'home.html',
        weather_lat=CONFIG.get('weather_lat', 48.9833),  # Mantes-la-Ville par défaut
        weather_lon=CONFIG.get('weather_lon', 1.7167),
        weather_city=CONFIG.get('weather_city', 'Mantes-la-Ville'),
        screensaver_timeout=CONFIG.get('screensaver_timeout_seconds', 10),
        screensaver_refresh=CONFIG.get('screensaver_refresh_seconds', 10)
    )

@app.route('/home')
def home():
    return render_template(
        'home.html',
        weather_lat=CONFIG.get('weather_lat', 48.9833),
        weather_lon=CONFIG.get('weather_lon', 1.7167),
        weather_city=CONFIG.get('weather_city', 'Mantes-la-Ville'),
        screensaver_timeout=CONFIG.get('screensaver_timeout_seconds', 10),
        screensaver_refresh=CONFIG.get('screensaver_refresh_seconds', 10)
    )

@app.route('/student')
def student_page():
    # Cette route est uniquement accessible avec un paramètre uid
    # Si pas d'uid, rediriger vers la page d'accueil
    uid = request.args.get('uid')
    if not uid:
        return redirect(url_for('home'))
    return render_template('student.html')

@app.route('/admin')
def admin_page():
    # Vérifier si l'utilisateur est connecté en tant qu'admin
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    return render_template('admin.html')

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username', '')
        password = data.get('password', '')
        
        # Vérifier les identifiants depuis config.json
        if (username == CONFIG.get('admin_username', 'admin') and 
            password == CONFIG.get('admin_password', 'admin')):
            session['admin_logged_in'] = True
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Identifiants incorrects'})
    
    # GET: afficher la page de connexion
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('home'))

@app.route('/activate', methods=['POST'])
def activate_motor():
    try:
        data = request.get_json()
        motor_id = int(data.get('motorId', 1))
        seconds = float(data.get('seconds', CONFIG.get('default_seconds', 5)))
        speed = int(data.get('speed', CONFIG.get('default_speed', 512)))
        
        if motor_controller.send_command(motor_id, seconds, speed):
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Échec envoi commande'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/status')
def connection_status():
    return jsonify({
        'connected': motor_controller.connected,
        'port': motor_controller.port,
        'serial_open': motor_controller.serial.is_open if motor_controller.serial else False,
        'thread_alive': motor_controller._tx_thread.is_alive() if motor_controller._tx_thread else False,
        'last_rfid': motor_controller.last_rfid,
        'last_rfid_time': motor_controller.last_rfid_time
    })


@app.route('/screensaver/trains')
def screensaver_trains():
        """Return next train departures to show on the screensaver.
        Try to use local API module if available then try common endpoints; fallback to sample data.
        """
        # Normalize helper used for different upstream data shapes
        def _normalize_trains(raw_trains):
            out = []
            for t in raw_trains:
                try:
                    # t may contain different shapes depending on upstream API
                    dep = t.get('departure_time') if isinstance(t, dict) else None
                    arr = t.get('arrival_time') if isinstance(t, dict) else None
                    if not dep:
                        # common alternative keys
                        dep = (t.get('stop_date_time') or {}).get('departure_date_time') if isinstance(t, dict) else None
                    if not arr:
                        arr = (t.get('stop_date_time') or {}).get('arrival_date_time') if isinstance(t, dict) else None

                    origin = t.get('origin') if isinstance(t, dict) else ''
                    destination = t.get('destination') if isinstance(t, dict) else ''
                    # fallback common fields
                    destination = destination or t.get('headsign') or (t.get('display_informations') or {}).get('headsign')
                    origin = origin or t.get('from') or t.get('origin_name')
                    platform = t.get('platform') or t.get('ArrivalPlatformName') or ''

                    out.append({
                        'departure_time': dep,
                        'arrival_time': arr,
                        'origin': origin,
                        'destination': destination,
                        'stop_name': t.get('stop_name') if isinstance(t, dict) else '',
                        'train_number': t.get('train_number') if isinstance(t, dict) else '',
                        'platform': platform,
                        'status': t.get('status') or (t.get('type') or '')
                    })
                except Exception:
                    # keep passing malformed entries through minimally
                    out.append(t)
            return out

        # Try to import local API module (API/API.py). We support both normal package import
        # and directly loading the source file in case the folder is not an importable package.
        try:
            api_mod = None
            spec = importlib.util.find_spec('API.API')
            if spec:
                api_mod = importlib.import_module('API.API')
            else:
                # Try to load directly from the repo path (works even if API isn't a package)
                import os
                api_path = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', 'API', 'API.py'))
                if os.path.exists(api_path):
                    spec2 = importlib.util.spec_from_file_location('api_local', api_path)
                    if spec2 and spec2.loader:
                        api_mod = importlib.util.module_from_spec(spec2)
                        spec2.loader.exec_module(api_mod)

            def _normalize_trains(raw_trains):
                out = []
                for t in raw_trains:
                    try:
                        # t may contain different shapes depending on upstream API
                        dep = t.get('departure_time') if isinstance(t, dict) else None
                        arr = t.get('arrival_time') if isinstance(t, dict) else None
                        if not dep:
                            # common alternative keys
                            dep = (t.get('stop_date_time') or {}).get('departure_date_time') if isinstance(t, dict) else None
                        if not arr:
                            arr = (t.get('stop_date_time') or {}).get('arrival_date_time') if isinstance(t, dict) else None

                        origin = t.get('origin') if isinstance(t, dict) else ''
                        destination = t.get('destination') if isinstance(t, dict) else ''
                        # fallback common fields
                        destination = destination or t.get('headsign') or (t.get('display_informations') or {}).get('headsign')
                        origin = origin or t.get('from') or t.get('origin_name')
                        platform = t.get('platform') or t.get('ArrivalPlatformName') or ''

                        out.append({
                            'departure_time': dep,
                            'arrival_time': arr,
                            'origin': origin,
                            'destination': destination,
                            'stop_name': t.get('stop_name') if isinstance(t, dict) else '',
                            'train_number': t.get('train_number') if isinstance(t, dict) else '',
                            'platform': platform,
                            'status': t.get('status') or (t.get('type') or '')
                        })
                    except Exception:
                        # keep passing malformed entries through minimally
                        out.append(t)
                return out

            if api_mod and hasattr(api_mod, 'get_real_time_trains_mantes'):
                try:
                    trains = api_mod.get_real_time_trains_mantes()
                    return jsonify({'success': True, 'source': 'local_module', 'trains': _normalize_trains(trains)[:4]})
                except Exception as e:
                    print('[screensaver/trains] local module error calling get_real_time_trains_mantes:', e)
                    # fall through to try HTTP endpoints
        except Exception as e:
            print('[screensaver/trains] import/load API.API failed:', e)

        # Try HTTP endpoints on likely ports
        host_port = request.host.split(':')[-1] if ':' in request.host else '80'
        candidates = [
            'http://127.0.0.1:5001/mantes-real-time',
            'http://127.0.0.1:5000/mantes-real-time',
            f'http://127.0.0.1:{host_port}/mantes-real-time',
            '/mantes-real-time',
            '/api/mantes-real-time'
        ]
        for url in candidates:
            try:
                if url.startswith('http'):
                    r = requests.get(url, timeout=3)
                else:
                    full = f'http://127.0.0.1:{host_port}{url}'
                    r = requests.get(full, timeout=3)
                if r.ok:
                    j = r.json()
                    trains = j.get('trains') or j.get('data') or []
                    return jsonify({'success': True, 'source': url, 'trains': _normalize_trains(trains)[:4]})
            except Exception as e:
                print(f'[screensaver/trains] fetch {url} failed:', e)

        # Fallback - sample data
        now = datetime.datetime.now()
        def fmt(mins):
            return (now + datetime.timedelta(minutes=mins)).strftime('%H:%M')

        sample = [
            {'train_number': 'A123', 'origin': 'Paris St-Lazare', 'destination': 'Mantes-la-Jolie', 'departure_time': fmt(5), 'arrival_time': fmt(35), 'platform': '2', 'status': 'on_time'},
            {'train_number': 'B456', 'origin': 'Cergy', 'destination': 'Mantes-la-Jolie', 'departure_time': fmt(12), 'arrival_time': fmt(42), 'platform': '1', 'status': 'on_time'},
            {'train_number': 'C789', 'origin': 'Paris St-Lazare', 'destination': 'Caen', 'departure_time': fmt(22), 'arrival_time': fmt(100), 'platform': '3', 'status': 'delayed'},
            {'train_number': 'D012', 'origin': 'Mantes-la-Jolie', 'destination': 'Cherbourg', 'departure_time': fmt(35), 'arrival_time': fmt(150), 'platform': '2', 'status': 'on_time'}
        ]

        return jsonify({'success': True, 'source': 'mock', 'trains': _normalize_trains(sample)}), 200

@app.route('/rfid_latest')
def rfid_latest():
    """Retourne le dernier UID RFID détecté"""
    # Vérifier si le contrôleur est connecté
    if not motor_controller.connected:
        print("[WARN] /rfid_latest appelé mais motor_controller non connecté")
        return jsonify({'uid': 'NONE', 'error': 'Arduino non connecté'})
    
    if motor_controller.last_rfid:
        uid = motor_controller.last_rfid
        print(f"[DEBUG] /rfid_latest retourne UID: {uid}")
        return jsonify({
            'uid': uid,
            'time': motor_controller.last_rfid_time
        })
    
    # Pas de carte détectée
    return jsonify({'uid': 'NONE'})

@app.route('/trigger_rfid', methods=['POST'])
def trigger_rfid():
    """Déclenche une lecture RFID sur l'Arduino"""
    try:
        print("[RFID] Déclenchement lecture RFID demandé")
        
        # Réinitialiser la dernière lecture
        motor_controller.last_rfid = None
        motor_controller.last_rfid_time = None
        print("[RFID] Dernière lecture RFID réinitialisée")
        
        # Vérifier la connexion
        if not motor_controller.connected:
            print("[RFID ERROR] Arduino non connecté")
            return jsonify({'success': False, 'message': 'Arduino non connecté'}), 500
        
        if not motor_controller.serial or not motor_controller.serial.is_open:
            print("[RFID ERROR] Port série fermé")
            return jsonify({'success': False, 'message': 'Port série non ouvert'}), 500
        
        # Envoyer la commande 'rfid' à l'Arduino
        motor_controller.tx_queue.put('rfid')
        print("[RFID] ✅ Commande 'rfid' envoyée à l'Arduino via queue")
        return jsonify({'success': True, 'message': 'Lecture RFID déclenchée'})
    except Exception as e:
        print(f"[RFID ERROR] Exception: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/transactions')
def transactions():
    try:
        # Filters
        user_filter = request.args.get('user_uid')  # Can be UID or name
        product_filter = request.args.get('product_id')  # Can be ID or name
        min_price = request.args.get('min_price')
        max_price = request.args.get('max_price')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        page = int(request.args.get('page', 1))
        page_size = int(request.args.get('page_size', 20))

        where_clauses = []
        params = []
        if user_filter:
            where_clauses.append('(u.uid LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)')
            pattern = f'%{user_filter}%'
            params.extend([pattern, pattern, pattern])
        if product_filter:
            where_clauses.append('(p.id = ? OR p.name LIKE ?)')
            params.append(product_filter)
            params.append(f'%{product_filter}%')
        if min_price:
            where_clauses.append('t.amount >= ?')
            params.append(min_price)
        if max_price:
            where_clauses.append('t.amount <= ?')
            params.append(max_price)
        if start_date:
            where_clauses.append('t.ts >= ?')
            params.append(start_date)
        if end_date:
            where_clauses.append('t.ts <= ?')
            params.append(end_date)

        where_sql = ('WHERE ' + ' AND '.join(where_clauses)) if where_clauses else ''

        offset = (page - 1) * page_size
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        # Get total count for pagination
        count_sql = f'''
            SELECT COUNT(*)
            FROM transactions t
            LEFT JOIN users u ON u.id = t.user_id
            LEFT JOIN products p ON p.id = t.product_id
            {where_sql}
        '''
        cur.execute(count_sql, params)
        total_count = cur.fetchone()[0]

        # Get paginated results
        sql = f'''
            SELECT t.id, u.first_name, u.last_name, u.uid, u.student_number, p.name, p.id, t.amount, t.description, t.ts
            FROM transactions t
            LEFT JOIN users u ON u.id = t.user_id
            LEFT JOIN products p ON p.id = t.product_id
            {where_sql}
            ORDER BY t.id DESC
            LIMIT ? OFFSET ?
        '''
        cur.execute(sql, params + [page_size, offset])
        rows = cur.fetchall()
        items = []
        for r in rows:
            items.append({
                'id': r[0],
                'user_name': f"{(r[1] or '').strip()} {(r[2] or '').strip()}".strip() or r[3],
                'user_uid': r[3],
                'student_number': r[4],
                'product_name': r[5],
                'product_id': r[6],
                'amount': float(r[7] or 0),
                'description': r[8] or '',
                'ts': r[9]
            })
        return jsonify({
            'success': True,
            'transactions': items,
            'total_count': total_count,
            'page': page,
            'page_size': page_size
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# CSV export endpoint
@app.route('/transactions/export')
def transactions_export():
    try:
        # Same filters as above
        user_filter = request.args.get('user_uid')  # Can be UID or name
        product_filter = request.args.get('product_id')  # Can be ID or name
        min_price = request.args.get('min_price')
        max_price = request.args.get('max_price')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        where_clauses = []
        params = []
        if user_filter:
            where_clauses.append('(u.uid LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)')
            pattern = f'%{user_filter}%'
            params.extend([pattern, pattern, pattern])
        if product_filter:
            where_clauses.append('(p.id = ? OR p.name LIKE ?)')
            params.append(product_filter)
            params.append(f'%{product_filter}%')
        if min_price:
            where_clauses.append('t.amount >= ?')
            params.append(min_price)
        if max_price:
            where_clauses.append('t.amount <= ?')
            params.append(max_price)
        if start_date:
            where_clauses.append('t.ts >= ?')
            params.append(start_date)
        if end_date:
            where_clauses.append('t.ts <= ?')
            params.append(end_date)

        where_sql = ('WHERE ' + ' AND '.join(where_clauses)) if where_clauses else ''

        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        sql = f'''
            SELECT t.id, u.first_name, u.last_name, u.uid, u.student_number, p.name, t.amount, t.description, t.ts
            FROM transactions t
            LEFT JOIN users u ON u.id = t.user_id
            LEFT JOIN products p ON p.id = t.product_id
            {where_sql}
            ORDER BY t.id DESC
        '''
        cur.execute(sql, params)
        rows = cur.fetchall()
        # Prepare CSV
        si = StringIO()
        cw = csv.writer(si)
        cw.writerow(['ID', 'Utilisateur', 'UID', 'N° Étudiant', 'Produit', 'Montant', 'Description', 'Date'])
        for r in rows:
            user_name = f"{(r[1] or '').strip()} {(r[2] or '').strip()}".strip() or r[3]
            cw.writerow([r[0], user_name, r[3], r[4] or '', r[5], float(r[6] or 0), r[7] or '', r[8]])
        output = si.getvalue()
        return Response(
            output,
            mimetype='text/csv',
            headers={"Content-Disposition": "attachment;filename=transactions.csv"}
        )
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/clear_rfid', methods=['POST'])
def clear_rfid():
    """Efface le dernier UID RFID lu (pour déconnexion)"""
    try:
        motor_controller.last_rfid = None
        motor_controller.last_rfid_time = None
        print("[RFID] UID effacé - prêt pour une nouvelle lecture")
        return jsonify({'success': True})
    except Exception as e:
        print(f"[ERROR] clear_rfid: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/connect', methods=['POST'])
def connect_api():
    if motor_controller.connect():
        return jsonify({'success': True})
    return jsonify({'success': False, 'message': 'Connexion échouée'})

@app.route('/disconnect', methods=['POST'])
def disconnect_api():
    motor_controller.disconnect()
    return jsonify({'success': True})

# --- API Products ---
@app.route('/products')
def get_products():
    try:
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        cur.execute('SELECT id, name, stock, price, image_blob IS NOT NULL as has_image FROM products ORDER BY id')
        rows = cur.fetchall()
        products = []
        for r in rows:
            products.append({
                'id': r[0],
                'name': r[1],
                'stock': r[2],
                'price': float(r[3]),
                'has_image': bool(r[4]),
                'image_url': url_for('product_image', product_id=r[0]) if r[4] else None
            })
        return jsonify({'success': True, 'products': products})
    except Exception as e:
        print(f"[DB] get_products failed: {e}")
        # Fallback
        products = [{'id': i, 'name': f'Produit {i}', 'stock': 10, 'price': 1.00} for i in range(1,5)]
        return jsonify({'success': True, 'products': products})

@app.route('/product_update', methods=['POST'])
def product_update():
    try:
        data = request.get_json()
        pid = int(data.get('id'))
        name = str(data.get('name'))
        stock = int(data.get('stock'))
        price = float(data.get('price'))
        
        # Validation prix strictement positif
        if price <= 0:
            return jsonify({'success': False, 'message': 'Le prix doit être strictement supérieur à 0'}), 400
        
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        cur.execute('UPDATE products SET name=?, stock=?, price=? WHERE id=?', 
                   (name, stock, price, pid))
        conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# --- Product images ---
@app.route('/product_image/<int:product_id>')
def product_image(product_id: int):
    try:
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        cur.execute('SELECT image_blob, image_mime FROM products WHERE id=?', (product_id,))
        row = cur.fetchone()
        if not row or row[0] is None:
            return Response(status=404)
        blob = row[0]
        mime = row[1] or 'image/jpeg'
        return Response(blob, content_type=mime)
    except Exception as e:
        print(f"[DB] product_image failed: {e}")
        return Response(status=500)

@app.route('/product_image_upload', methods=['POST'])
def product_image_upload():
    try:
        pid_str = request.form.get('id')
        if not pid_str:
            return jsonify({'success': False, 'message': 'ID produit manquant'}), 400
        pid = int(pid_str)
        file = request.files.get('file')
        if not file:
            return jsonify({'success': False, 'message': 'Fichier manquant'}), 400
        data = file.read()
        if len(data) > 4*1024*1024:
            return jsonify({'success': False, 'message': 'Image trop grande (max 4MB)'}), 400
        mime = file.mimetype or 'application/octet-stream'
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        cur.execute('UPDATE products SET image_blob=?, image_mime=? WHERE id=?', (sqlite3.Binary(data), mime, pid))
        conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# --- API Users ---
@app.route('/check_user/<uid>')
def check_user(uid):
    """Vérifie si un utilisateur existe par son UID RFID ou numéro étudiant"""
    try:
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        # Chercher d'abord par UID RFID
        cur.execute('SELECT id, uid, first_name, last_name, balance, student_number FROM users WHERE uid=?', (uid,))
        row = cur.fetchone()
        
        # Si pas trouvé, chercher par numéro étudiant
        if not row:
            cur.execute('SELECT id, uid, first_name, last_name, balance, student_number FROM users WHERE student_number=?', (uid,))
            row = cur.fetchone()
        
        if row:
            user = {
                'id': row[0],
                'uid': row[1],
                'first_name': row[2] or '',
                'last_name': row[3] or '',
                'balance': float(row[4] or 0),
                'student_number': row[5] or ''
            }
            return jsonify({'success': True, 'user': user})
        else:
            return jsonify({'success': False, 'message': 'Utilisateur non trouvé'})
    except Exception as e:
        print(f"[DB] check_user failed: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/users')
def get_users():
    try:
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        cur.execute('SELECT id, uid, first_name, last_name, balance, first_seen, last_seen, hits, student_number FROM users ORDER BY id')
        rows = cur.fetchall()
        users = []
        for r in rows:
            users.append({
                'id': r[0],
                'uid': r[1],
                'first_name': r[2] or '',
                'last_name': r[3] or '',
                'balance': float(r[4] or 0),
                'first_seen': str(r[5]) if r[5] else '',
                'last_seen': str(r[6]) if r[6] else '',
                'hits': r[7] or 0,
                'student_number': r[8] or ''
            })
        return jsonify({'success': True, 'users': users})
    except Exception as e:
        print(f"[DB] get_users failed: {e}")
        return jsonify({'success': True, 'users': []})

@app.route('/register_user', methods=['POST'])
def register_user():
    try:
        data = request.get_json()
        uid = data.get('uid')
        first_name = (data.get('first_name') or '').strip().lower()
        last_name = (data.get('last_name') or '').strip().lower()
        balance = float(data.get('balance', 0))
        student_number = (data.get('student_number') or '').strip()
        
        # Validation 1: Prénom ET nom obligatoires
        if not first_name or not last_name:
            return jsonify({'success': False, 'message': 'Le prénom et le nom sont obligatoires'}), 400
        
        # Si on update par ID
        user_id_to_update = None
        if 'id' in data and data.get('id'):
            user_id_to_update = data.get('id')
            conn = motor_controller._get_db_conn()
            cur = conn.cursor()
            cur.execute('SELECT uid, student_number FROM users WHERE id=?', (user_id_to_update,))
            row = cur.fetchone()
            if row:
                uid = row[0]
                # Si pas de nouveau numéro fourni, garder l'ancien
                if not student_number and row[1]:
                    student_number = row[1]
        
        if not uid:
            return jsonify({'success': False, 'message': 'UID requis'}), 400
        
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        
        # Validation 2: Vérifier si un compte avec le même prénom ET nom existe déjà
        if user_id_to_update:
            # Lors d'une mise à jour, exclure l'utilisateur actuel de la recherche
            cur.execute('SELECT id FROM users WHERE LOWER(first_name)=? AND LOWER(last_name)=? AND id!=?', 
                       (first_name, last_name, user_id_to_update))
        else:
            cur.execute('SELECT id FROM users WHERE LOWER(first_name)=? AND LOWER(last_name)=?', 
                       (first_name, last_name))
        
        duplicate_user = cur.fetchone()
        if duplicate_user:
            return jsonify({'success': False, 'message': 'Un compte avec ce prénom et nom existe déjà'}), 400
        
        # AUTO-GÉNÉRATION: Si pas de numéro étudiant fourni, en générer un automatiquement
        if not student_number:
            student_number = motor_controller._generate_student_number()
            print(f"[REGISTER] Numéro étudiant auto-généré: {student_number}")
        
        # Validation 3: Vérifier si le numéro étudiant existe déjà
        if user_id_to_update:
            cur.execute('SELECT id FROM users WHERE student_number=? AND id!=?', (student_number, user_id_to_update))
        else:
            cur.execute('SELECT id FROM users WHERE student_number=?', (student_number,))
        if cur.fetchone():
            return jsonify({'success': False, 'message': 'Ce numéro étudiant existe déjà'}), 400
        
        # Vérifier si l'UID existe déjà
        cur.execute('SELECT id FROM users WHERE uid=?', (uid,))
        row = cur.fetchone()
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        if row:
            cur.execute('UPDATE users SET first_name=?, last_name=?, balance=?, student_number=? WHERE uid=?', 
                       (first_name, last_name, balance, student_number, uid))
        else:
            cur.execute('INSERT INTO users (uid, first_seen, last_seen, hits, first_name, last_name, balance, student_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', 
                       (uid, now, now, 0, first_name, last_name, balance, student_number))
        conn.commit()
        
        # Retourner le numéro généré pour affichage
        return jsonify({'success': True, 'student_number': student_number})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/delete_user', methods=['POST'])
def delete_user():
    try:
        data = request.get_json()
        uid = data.get('uid')
        
        if 'id' in data and data.get('id'):
            conn = motor_controller._get_db_conn()
            cur = conn.cursor()
            cur.execute('SELECT uid FROM users WHERE id=?', (data.get('id'),))
            row = cur.fetchone()
            if row:
                uid = row[0]
        
        if not uid:
            return jsonify({'success': False, 'message': 'uid ou id requis'}), 400
        
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        cur.execute('DELETE FROM users WHERE uid=?', (uid,))
        conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/purchase', methods=['POST'])
def purchase():
    """Acheter un produit avec le compte utilisateur"""
    try:
        data = request.get_json()
        uid = data.get('uid')
        product_id = int(data.get('product_id'))
        
        print(f"[PURCHASE] UID reçu: '{uid}', Product ID: {product_id}")
        
        if not uid or not product_id:
            print(f"[PURCHASE ERROR] Données manquantes - UID: {uid}, Product: {product_id}")
            return jsonify({'success': False, 'message': 'UID et product_id requis'}), 400
        
        conn = motor_controller._get_db_conn()
        cur = conn.cursor()
        
        # Vérifier l'utilisateur (par UID RFID ou numéro étudiant)
        print(f"[PURCHASE] Recherche utilisateur avec UID: '{uid}'")
        cur.execute('SELECT id, first_name, last_name, balance FROM users WHERE uid=?', (uid,))
        user_row = cur.fetchone()
        
        # Si pas trouvé par UID RFID, chercher par numéro étudiant
        if not user_row:
            print(f"[PURCHASE] UID RFID non trouvé, recherche par numéro étudiant: '{uid}'")
            cur.execute('SELECT id, first_name, last_name, balance FROM users WHERE student_number=?', (uid,))
            user_row = cur.fetchone()
        
        if not user_row:
            print(f"[PURCHASE ERROR] Utilisateur non trouvé pour UID/Numéro: '{uid}'")
            # Lister tous les utilisateurs pour debug
            cur.execute('SELECT uid, student_number, first_name FROM users')
            all_users = cur.fetchall()
            print(f"[PURCHASE DEBUG] Utilisateurs en base: {all_users}")
            return jsonify({'success': False, 'message': 'Utilisateur non trouvé'}), 404
        
        print(f"[PURCHASE] Utilisateur trouvé: {user_row[1]} {user_row[2]}, Balance: {user_row[3]}€")
        user_balance = float(user_row[3] or 0)
        
        # Vérifier le produit
        cur.execute('SELECT id, name, price, stock FROM products WHERE id=?', (product_id,))
        product_row = cur.fetchone()
        if not product_row:
            return jsonify({'success': False, 'message': 'Produit non trouvé'}), 404
        
        product_price = float(product_row[2])
        product_stock = int(product_row[3])
        product_name = product_row[1]
        
        # Vérifications
        if product_price <= 0:
            return jsonify({'success': False, 'message': 'Prix du produit invalide (> 0 requis)'}), 400
        if product_stock <= 0:
            return jsonify({'success': False, 'message': 'Produit en rupture de stock'}), 400
        
        if user_balance < product_price:
            return jsonify({'success': False, 'message': f'Solde insuffisant. Solde: {user_balance}€, Prix: {product_price}€'}), 400

        # Effectuer l'achat
        new_balance = user_balance - product_price
        new_stock = product_stock - 1

        # Utiliser l'ID de l'utilisateur (plus fiable que l'UID qui peut être un numéro étudiant)
        user_id = int(user_row[0])
        cur.execute('UPDATE users SET balance=? WHERE id=?', (new_balance, user_id))
        cur.execute('UPDATE products SET stock=? WHERE id=?', (new_stock, product_id))

        # Enregistrer transaction
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cur.execute('INSERT INTO transactions (user_id, product_id, amount, description, ts) VALUES (?, ?, ?, ?, ?)',
                    (int(user_row[0]), int(product_row[0]), -product_price, f"Achat {product_name}", now))
        conn.commit()
        print(f"[PURCHASE] Transaction enregistrée - Nouveau solde: {new_balance}€, Nouveau stock: {new_stock}")

        # Activer le moteur pour distribuer le produit
        print(f"[MOTOR] Envoi commande moteur - ID: {product_id}, Durée: {CONFIG.get('default_seconds', 5)}s, Vitesse: {CONFIG.get('default_speed', 1002)}")
        motor_success = motor_controller.send_command(product_id, CONFIG.get('default_seconds', 5), CONFIG.get('default_speed', 1002))
        
        if not motor_success:
            print(f"[MOTOR WARN] Échec envoi commande moteur - Arduino non connecté?")
        else:
            print(f"[MOTOR] Commande moteur envoyée avec succès")
        
        # Déconnexion de l'étudiant après achat
        session.clear()
        return jsonify({
            'success': True,
            'message': f'{product_name} acheté!',
            'new_balance': new_balance,
            'new_stock': new_stock,
            'logout': True
        })
    except Exception as e:
        print(f"[ERROR] purchase: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

if __name__ == '__main__':
    import argparse
    import socket
    
    # Arguments en ligne de commande
    parser = argparse.ArgumentParser(description='RFID Distributor Flask App')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind to')
    parser.add_argument('--port', type=int, default=5000, help='Port to bind to')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    args = parser.parse_args()
    
    # Afficher les informations système
    print(f"\n🚀 Démarrage du Distributeur RFID")
    print(f"💻 Système: {motor_controller.get_system_info()}")
    
    # Lister les ports
    print("\n=== PORTS SÉRIE DISPONIBLES ===")
    for port in motor_controller.list_ports():
        print(f"Port trouvé: {port}")
    print("=============================\n")
    
    # Connexion Arduino
    if motor_controller.connect():
        print("✅ [INFO] Connexion Arduino réussie")
    else:
        print("❌ [ERROR] Échec connexion Arduino")
    
    # Initialiser la DB
    try:
        motor_controller.init_db()
        print("✅ [INFO] Base de données initialisée")
    except Exception as e:
        print(f"⚠️ [WARN] Impossible d'initialiser la DB: {e}")
    
    # Afficher les URLs d'accès
    def get_local_ip():
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "localhost"
    
    local_ip = get_local_ip()
    print(f"\n🌐 Application accessible sur:")
    print(f"   Local:  http://localhost:{args.port}")
    print(f"   Réseau: http://{local_ip}:{args.port}")
    print(f"\n⚠️ Appuyez sur Ctrl+C pour arrêter\n")
    
    # Lancement de l'application
    app.run(
        host=args.host, 
        port=args.port, 
        debug=args.debug, 
        use_reloader=False
    )

import sqlite3
import json

# Charger la config
with open('config.json') as f:
    config = json.load(f)

db_file = config.get('db_file', 'distributor.db')

# Se connecter à la base de données
conn = sqlite3.connect(db_file)
conn.row_factory = sqlite3.Row
cur = conn.cursor()

print("=== LISTE DES UTILISATEURS ===\n")
cur.execute('SELECT id, uid, first_name, last_name, balance FROM users')
rows = cur.fetchall()

if not rows:
    print("Aucun utilisateur trouvé dans la base de données.")
else:
    for row in rows:
        print(f"ID: {row['id']}")
        print(f"UID: {row['uid']}")
        print(f"Prénom: '{row['first_name'] or '(vide)'}'")
        print(f"Nom: '{row['last_name'] or '(vide)'}'")
        print(f"Solde: {row['balance']} €")
        print("-" * 40)

conn.close()

#!/usr/bin/env python3

import serial
import json
import os
from serial.tools import list_ports

print("=== TEST RAPIDE ARDUINO ===\n")

# 1. Charger la configuration
try:
    with open('config.json', 'r') as f:
        config = json.load(f)
    port = config['com_port']
    baudrate = config['baudrate']
    print(f"✓ Configuration chargée: {port} à {baudrate} bauds")
except Exception as e:
    print(f"✗ Erreur lecture config: {e}")
    exit(1)

# 2. Lister les ports disponibles
print("\n--- Ports série disponibles ---")
available_ports = [p.device for p in list_ports.comports()]
if available_ports:
    for p in list_ports.comports():
        print(f"  • {p.device} - {p.description}")
else:
    print("  Aucun port série trouvé")

# 3. Vérifier si le port configuré existe
print(f"\n--- Vérification du port {port} ---")
if os.path.exists(port):
    print(f"✓ Le port {port} existe")
else:
    print(f"✗ Le port {port} n'existe pas")
    if available_ports:
        print(f"Ports disponibles: {available_ports}")

# 4. Tester la connexion
print(f"\n--- Test de connexion sur {port} ---")
try:
    ser = serial.Serial(port=port, baudrate=baudrate, timeout=1)
    print(f"✓ Connexion réussie!")
    ser.close()
    print("✓ Fermeture propre")
except PermissionError:
    print("✗ Permission refusée")
    print("  Solution: sudo usermod -a -G dialout $USER")
except serial.SerialException as e:
    print(f"✗ Erreur série: {e}")
except Exception as e:
    print(f"✗ Erreur: {e}")

print("\n=== FIN TEST ===")
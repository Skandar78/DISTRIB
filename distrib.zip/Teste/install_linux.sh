#!/bin/bash

# Script d'installation pour Lubuntu/Ubuntu
# Distributer RFID System

echo "🚀 Installation du système RFID Distributer sur Linux..."

# Couleurs pour les messages
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Vérification que nous sommes sur Ubuntu/Debian
if ! command -v apt &> /dev/null; then
    print_error "Ce script est conçu pour Ubuntu/Debian avec apt"
    exit 1
fi

print_status "Mise à jour des paquets système..."
sudo apt update

print_status "Installation des dépendances système..."
sudo apt install -y python3 python3-pip python3-venv git curl

print_status "Installation des outils série..."
sudo apt install -y minicom screen setserial

print_status "Ajout de l'utilisateur au groupe dialout (pour accès série)..."
sudo usermod -a -G dialout $USER
print_warning "Vous devrez vous reconnecter pour que les permissions prennent effet!"

print_status "Création de l'environnement virtuel Python..."
python3 -m venv venv

print_status "Activation de l'environnement virtuel..."
source venv/bin/activate

print_status "Installation des packages Python..."
pip install --upgrade pip
pip install -r requirements.txt

print_status "Détection automatique du port Arduino..."
python3 detect_port.py

print_status "Test de la base de données..."
python3 test_db.py

print_success "Installation terminée!"
echo ""
echo "📋 Prochaines étapes:"
echo "1. Reconnectez-vous (logout/login) pour les permissions série"
echo "2. Activez l'environnement virtuel: source venv/bin/activate"
echo "3. Lancez l'application: python3 app.py"
echo ""
echo "🔧 Commandes utiles:"
echo "- Détecter Arduino: python3 detect_port.py"
echo "- Lister ports série: ls /dev/tty*"
echo "- Test port série: minicom -D /dev/ttyUSB0"
echo ""
print_warning "Si l'Arduino n'est pas détecté, vérifiez les drivers USB-Série"
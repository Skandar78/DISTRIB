from flask import Flask, jsonify, render_template_string
import requests
import xml.etree.ElementTree as ET
from datetime import datetime

app = Flask(__name__)

def get_real_time_trains_mantes():
    """Récupère les horaires temps réel pour Mantes via l'API SIRI Lite SNCF."""
    trains = []
    
    try:
        # API SIRI Lite SNCF - données temps réel
        url = 'https://proxy.transport.data.gouv.fr/resource/sncf-siri-lite-estimated-timetable'
        response = requests.get(url, timeout=30)
        
        if response.status_code == 200:
            # Parser le XML
            root = ET.fromstring(response.content)
            
            # Espaces de noms XML
            namespaces = {
                'siri': 'http://www.siri.org.uk/siri'
            }
            
            # Trouver tous les voyages
            journeys = root.findall('.//siri:EstimatedVehicleJourney', namespaces)
            
            for journey in journeys:
                # Vérifier si c'est un voyage qui concerne Mantes
                has_mantes = False
                mantes_calls = []
                
                # Rechercher dans les arrêts estimés
                estimated_calls = journey.findall('.//siri:EstimatedCall', namespaces)
                
                for call in estimated_calls:
                    stop_name_elem = call.find('siri:StopPointName', namespaces)
                    if stop_name_elem is not None:
                        stop_name = stop_name_elem.text
                        if stop_name and 'mantes' in stop_name.lower():
                            has_mantes = True
                            
                            # Extraire les informations d'horaire
                            arrival_elem = call.find('.//siri:ExpectedArrivalTime', namespaces)
                            departure_elem = call.find('.//siri:ExpectedDepartureTime', namespaces)
                            platform_elem = call.find('.//siri:ArrivalPlatformName', namespaces)
                            
                            arrival_time = arrival_elem.text if arrival_elem is not None else None
                            departure_time = departure_elem.text if departure_elem is not None else None
                            platform = platform_elem.text if platform_elem is not None else ""
                            
                            mantes_calls.append({
                                'stop_name': stop_name,
                                'arrival_time': arrival_time,
                                'departure_time': departure_time,
                                'platform': platform
                            })
                
                if has_mantes:
                    # Extraire les informations du voyage
                    line_ref_elem = journey.find('siri:LineRef', namespaces)
                    origin_elem = journey.find('.//siri:OriginName', namespaces)
                    destination_elem = journey.find('.//siri:DestinationName', namespaces)
                    vehicle_ref_elem = journey.find('siri:VehicleRef', namespaces)
                    
                    line_ref = line_ref_elem.text if line_ref_elem is not None else ""
                    origin = origin_elem.text if origin_elem is not None else ""
                    destination = destination_elem.text if destination_elem is not None else ""
                    train_number = vehicle_ref_elem.text if vehicle_ref_elem is not None else ""
                    
                    for call in mantes_calls:
                        trains.append({
                            'train_number': train_number,
                            'line': line_ref,
                            'origin': origin,
                            'destination': destination,
                            'stop_name': call['stop_name'],
                            'arrival_time': call['arrival_time'],
                            'departure_time': call['departure_time'],
                            'platform': call['platform'],
                            'status': 'real_time',
                            'source': 'SNCF SIRI Lite'
                        })
            
            # Trier par heure d'arrivée/départ
            trains.sort(key=lambda x: x['arrival_time'] or x['departure_time'] or '')
            
        else:
            raise Exception(f"Erreur API SIRI Lite: {response.status_code}")
            
    except Exception as e:
        print(f"Erreur récupération temps réel Mantes: {e}")
        raise e
    
    return trains

@app.route("/")
def home():
    html_template = '''
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🚂 Mantes-la-Jolie - Horaires Temps Réel</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 3em;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .header p {
            font-size: 1.3em;
            opacity: 0.9;
        }
        
        .status-badge {
            display: inline-block;
            background: #27ae60;
            color: white;
            padding: 8px 16px;
            border-radius: 25px;
            font-weight: bold;
            margin-top: 15px;
            font-size: 0.9em;
        }
        
        .main-content {
            padding: 40px;
        }
        
        .info-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            border-left: 5px solid #667eea;
        }
        
        .info-section h2 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 1.5em;
        }
        
        .controls {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            min-width: 200px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }
        
        .btn-info {
            background: linear-gradient(135deg, #17a2b8 0%, #6f42c1 100%);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        
        .trains-container {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            margin-top: 20px;
            display: none;
        }
        
        .train-item {
            background: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 10px;
            border-left: 5px solid #667eea;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.2s;
        }
        
        .train-item:hover {
            transform: translateX(5px);
        }
        
        .train-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }
        
        .train-route {
            font-size: 1.2em;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .train-time {
            background: #667eea;
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: bold;
        }
        
        .train-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .detail-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .detail-icon {
            font-size: 1.2em;
        }
        
        .loading {
            text-align: center;
            padding: 40px;
            color: #6c757d;
            font-style: italic;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-top: 4px solid #667eea;
        }
        
        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 10px;
        }
        
        .stat-label {
            color: #6c757d;
            font-weight: 500;
        }
        
        .alert {
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            border-left: 5px solid;
        }
        
        .alert-success {
            background: #d4edda;
            border-color: #28a745;
            color: #155724;
        }
        
        .alert-error {
            background: #f8d7da;
            border-color: #dc3545;
            color: #721c24;
        }
        
        @media (max-width: 768px) {
            .header h1 {
                font-size: 2em;
            }
            
            .controls {
                flex-direction: column;
                align-items: center;
            }
            
            .btn {
                min-width: 250px;
            }
            
            .train-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .train-details {
                grid-template-columns: 1fr;
            }
        }
        
        .refresh-info {
            text-align: center;
            margin-top: 20px;
            color: #6c757d;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚂 Mantes-la-Jolie</h1>
            <p>Horaires de trains en temps réel</p>
            <div class="status-badge">✅ API SNCF SIRI Lite Active</div>
        </div>
        
        <div class="main-content">
            <div class="info-section">
                <h2>📍 Informations Station</h2>
                <p><strong>Gare :</strong> Mantes-la-Jolie / Mantes Station</p>
                <p><strong>Code UIC :</strong> 87381590</p>
                <p><strong>Lignes desservies :</strong> J (Paris Saint-Lazare), N (Paris Montparnasse), Intercités</p>
                <p><strong>Zone :</strong> Île-de-France, Yvelines (78)</p>
            </div>
            
            <div class="stats" id="stats">
                <div class="stat-card">
                    <div class="stat-number" id="trainCount">-</div>
                    <div class="stat-label">Trains détectés</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" id="updateTime">-</div>
                    <div class="stat-label">Dernière MAJ</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">100%</div>
                    <div class="stat-label">Temps réel</div>
                </div>
            </div>
            
            <div class="controls">
                <button class="btn btn-primary" onclick="loadRealTimeTrains()">
                    🔄 Actualiser les horaires
                </button>
                <button class="btn btn-success" onclick="loadRealTimeTrains()">
                    🚆 Voir tous les trains
                </button>
                <button class="btn btn-info" onclick="showAPIInfo()">
                    📊 Informations API
                </button>
            </div>
            
            <div id="trainsContainer" class="trains-container">
                <h3>🚂 Trains en temps réel</h3>
                <div id="trainsList"></div>
                <div class="refresh-info">
                    Les horaires sont mis à jour en temps réel depuis l'API SNCF SIRI Lite
                </div>
            </div>
            
            <div id="alerts"></div>
        </div>
    </div>

    <script>
        let trainsData = [];
        
        function showAlert(message, type = 'success') {
            const alertsContainer = document.getElementById('alerts');
            const alertClass = type === 'success' ? 'alert-success' : 'alert-error';
            
            alertsContainer.innerHTML = `
                <div class="alert ${alertClass}">
                    ${message}
                </div>
            `;
            
            setTimeout(() => {
                alertsContainer.innerHTML = '';
            }, 5000);
        }
        
        function formatTime(timeString) {
            if (!timeString) return 'N/A';
            try {
                const date = new Date(timeString);
                return date.toLocaleTimeString('fr-FR', {
                    hour: '2-digit',
                    minute: '2-digit'
                });
            } catch (e) {
                return timeString;
            }
        }
        
        function updateStats(count) {
            document.getElementById('trainCount').textContent = count;
            document.getElementById('updateTime').textContent = new Date().toLocaleTimeString('fr-FR', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }
        
        async function loadRealTimeTrains() {
            const container = document.getElementById('trainsContainer');
            const trainsList = document.getElementById('trainsList');
            
            // Afficher le container et le loading
            container.style.display = 'block';
            trainsList.innerHTML = '<div class="loading">⏳ Chargement des horaires temps réel...</div>';
            
            try {
                const response = await fetch('/mantes-real-time');
                const data = await response.json();
                
                if (data.status === 'success') {
                    trainsData = data.trains;
                    updateStats(data.count);
                    
                    if (data.trains && data.trains.length > 0) {
                        let html = '';
                        
                        data.trains.forEach((train, index) => {
                            const arrivalTime = formatTime(train.arrival_time);
                            const departureTime = formatTime(train.departure_time);
                            const timeDisplay = departureTime !== 'N/A' ? departureTime : arrivalTime;
                            
                            html += `
                                <div class="train-item">
                                    <div class="train-header">
                                        <div class="train-route">
                                            ${train.origin || 'Origine'} ➜ ${train.destination || 'Destination'}
                                        </div>
                                        <div class="train-time">${timeDisplay}</div>
                                    </div>
                                    <div class="train-details">
                                        <div class="detail-item">
                                            <span class="detail-icon">🚉</span>
                                            <span><strong>Arrêt :</strong> ${train.stop_name}</span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="detail-icon">🛤️</span>
                                            <span><strong>Ligne :</strong> ${train.line || 'N/A'}</span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="detail-icon">🚏</span>
                                            <span><strong>Quai :</strong> ${train.platform || 'Non spécifié'}</span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="detail-icon">⏰</span>
                                            <span><strong>Arrivée :</strong> ${arrivalTime}</span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="detail-icon">🚀</span>
                                            <span><strong>Départ :</strong> ${departureTime}</span>
                                        </div>
                                        <div class="detail-item">
                                            <span class="detail-icon">📊</span>
                                            <span><strong>Statut :</strong> ${train.status}</span>
                                        </div>
                                    </div>
                                </div>
                            `;
                        });
                        
                        trainsList.innerHTML = html;
                        showAlert(`✅ ${data.count} trains chargés avec succès depuis l'API SNCF SIRI Lite`, 'success');
                    } else {
                        trainsList.innerHTML = '<div class="loading">Aucun train détecté actuellement pour Mantes-la-Jolie</div>';
                        showAlert('ℹ️ Aucun train en circulation actuellement', 'success');
                    }
                } else {
                    throw new Error(data.error || 'Erreur API');
                }
                
            } catch (error) {
                trainsList.innerHTML = `<div class="loading">❌ Erreur de chargement: ${error.message}</div>`;
                showAlert(`❌ Erreur: ${error.message}`, 'error');
            }
        }
        
        function showAPIInfo() {
            showAlert(`
                📊 <strong>Informations API</strong><br>
                • Source: SNCF SIRI Lite<br>
                • Mise à jour: Temps réel<br>
                • Couverture: Réseau SNCF national<br>
                • Endpoint: /mantes-real-time
            `, 'success');
        }
        
        // Chargement automatique au démarrage
        window.addEventListener('load', function() {
            setTimeout(loadRealTimeTrains, 1000);
            
            // Auto-refresh toutes les 2 minutes
            setInterval(loadRealTimeTrains, 120000);
        });
        
        // Actualisation au clic
        document.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                loadRealTimeTrains();
            }
        });
    </script>
</body>
</html>
    '''
    return render_template_string(html_template)

@app.route("/mantes-real-time")
def mantes_real_time():
    """Récupère les horaires temps réel pour Mantes via l'API SIRI Lite SNCF."""
    try:
        trains = get_real_time_trains_mantes()
        
        return jsonify({
            "station": "Mantes-la-Jolie / Mantes Station",
            "count": len(trains),
            "source": "SNCF SIRI Lite - Temps réel",
            "trains": trains,
            "timestamp": datetime.now().isoformat(),
            "status": "success",
            "note": "Horaires de trains en temps réel (pas d'ouverture de gare)"
        })
        
    except Exception as e:
        return jsonify({
            "station": "Mantes-la-Jolie / Mantes Station",
            "count": 0,
            "source": "SNCF SIRI Lite",
            "trains": [],
            "error": str(e),
            "timestamp": datetime.now().isoformat(),
            "status": "error"
        }), 500

if __name__ == "__main__":
    print("🚂 API Mantes Temps Réel - Serveur de test")
    print("🌐 http://127.0.0.1:5001/mantes-real-time")
    app.run(host="0.0.0.0", port=5001, debug=True)
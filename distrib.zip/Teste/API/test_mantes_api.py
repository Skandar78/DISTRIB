import requests
import xml.etree.ElementTree as ET
from datetime import datetime

def get_real_time_trains_mantes():
    """Récupère les horaires temps réel pour Mantes via l'API SIRI Lite SNCF."""
    trains = []
    
    try:
        # API SIRI Lite SNCF - données temps réel
        url = 'https://proxy.transport.data.gouv.fr/resource/sncf-siri-lite-estimated-timetable'
        response = requests.get(url, timeout=30)
        
        if response.status_code == 200:
            # Parser le XML
            root = ET.fromstring(response.content)
            
            # Espaces de noms XML
            namespaces = {
                'siri': 'http://www.siri.org.uk/siri'
            }
            
            # Trouver tous les voyages
            journeys = root.findall('.//siri:EstimatedVehicleJourney', namespaces)
            print(f"Voyages trouvés: {len(journeys)}")
            
            for journey in journeys:
                # Vérifier si c'est un voyage qui concerne Mantes
                has_mantes = False
                mantes_calls = []
                
                # Rechercher dans les arrêts estimés
                estimated_calls = journey.findall('.//siri:EstimatedCall', namespaces)
                
                for call in estimated_calls:
                    stop_name_elem = call.find('siri:StopPointName', namespaces)
                    if stop_name_elem is not None:
                        stop_name = stop_name_elem.text
                        if stop_name and 'mantes' in stop_name.lower():
                            has_mantes = True
                            
                            # Extraire les informations d'horaire
                            arrival_elem = call.find('.//siri:ExpectedArrivalTime', namespaces)
                            departure_elem = call.find('.//siri:ExpectedDepartureTime', namespaces)
                            platform_elem = call.find('.//siri:ArrivalPlatformName', namespaces)
                            
                            arrival_time = arrival_elem.text if arrival_elem is not None else None
                            departure_time = departure_elem.text if departure_elem is not None else None
                            platform = platform_elem.text if platform_elem is not None else ""
                            
                            mantes_calls.append({
                                'stop_name': stop_name,
                                'arrival_time': arrival_time,
                                'departure_time': departure_time,
                                'platform': platform
                            })
                
                if has_mantes:
                    # Extraire les informations du voyage
                    line_ref_elem = journey.find('siri:LineRef', namespaces)
                    origin_elem = journey.find('.//siri:OriginName', namespaces)
                    destination_elem = journey.find('.//siri:DestinationName', namespaces)
                    vehicle_ref_elem = journey.find('siri:VehicleRef', namespaces)
                    
                    line_ref = line_ref_elem.text if line_ref_elem is not None else ""
                    origin = origin_elem.text if origin_elem is not None else ""
                    destination = destination_elem.text if destination_elem is not None else ""
                    train_number = vehicle_ref_elem.text if vehicle_ref_elem is not None else ""
                    
                    for call in mantes_calls:
                        trains.append({
                            'train_number': train_number,
                            'line': line_ref,
                            'origin': origin,
                            'destination': destination,
                            'stop_name': call['stop_name'],
                            'arrival_time': call['arrival_time'],
                            'departure_time': call['departure_time'],
                            'platform': call['platform'],
                            'status': 'real_time',
                            'source': 'SNCF SIRI Lite'
                        })
            
            # Trier par heure d'arrivée/départ
            trains.sort(key=lambda x: x['arrival_time'] or x['departure_time'] or '')
            
        else:
            raise Exception(f"Erreur API SIRI Lite: {response.status_code}")
            
    except Exception as e:
        print(f"Erreur récupération temps réel Mantes: {e}")
        raise e
    
    return trains

if __name__ == "__main__":
    print("Test de la fonction Mantes temps réel...")
    
    try:
        trains = get_real_time_trains_mantes()
        
        print(f"Nombre de trains trouvés: {len(trains)}")
        
        for i, train in enumerate(trains[:5]):
            print(f"\n{i+1}. Train {train['train_number']}")
            print(f"   Ligne: {train['line']}")
            print(f"   {train['origin']} ➜ {train['destination']}")
            print(f"   Arrêt: {train['stop_name']}")
            print(f"   Arrivée: {train['arrival_time']}")
            print(f"   Départ: {train['departure_time']}")
            print(f"   Quai: {train['platform']}")
            
        # Test d'un résultat JSON
        result = {
            "station": "Mantes-la-Jolie / Mantes Station",
            "count": len(trains),
            "source": "SNCF SIRI Lite - Temps réel",
            "trains": trains,
            "timestamp": datetime.now().isoformat(),
            "status": "success",
            "note": "Horaires de trains en temps réel (pas d'ouverture de gare)"
        }
        
        print(f"\nRésultat JSON préparé avec {result['count']} trains")
        
    except Exception as e:
        print(f"Erreur: {e}")
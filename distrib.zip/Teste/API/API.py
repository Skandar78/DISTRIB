import requests
from flask import Flask, request, jsonify, render_template
from urllib.parse import quote_plus
from datetime import datetime, timedelta
import json
import xml.etree.ElementTree as ET

# API.py
# Service Flask qui utilise l'API SNCF Open Data (gratuite, sans clé requise)
# Pour les horaires de trains en temps réel
# Usage:
# 1) Installer dépendances: pip install flask requests
# 2) Lancer: python API.py
# 3) Accéder: http://127.0.0.1:5000/

app = Flask(__name__)

# API SNCF Connect - Données ouvertes, pas de clé requise
SNCF_BASE = "https://data.sncf.com/api/records/1.0/search/"
TRANSPORT_BASE = "https://transport.data.gouv.fr/api/datasets"

print("🚂 API Transport - Données réelles uniquement")
print("✅ Utilise SNCF Connect, Navitia, et Transport.data.gouv.fr")
print("🌐 Interface disponible sur http://127.0.0.1:5000/")
print("⚠️  Aucune donnée de démonstration - APIs réelles requises\n")

def find_station_by_name(name):
    """Trouve les gares correspondant au nom fourni via des APIs réelles uniquement."""
    stations = []
    
    # Utiliser l'API Transport.data.gouv.fr
    try:
        url = "https://transport.data.gouv.fr/api/datasets"
        params = {"q": name, "type": "public-transit"}
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            for item in data.get("data", [])[:10]:
                stations.append({
                    "name": item.get("title", ""),
                    "code": item.get("id", ""),
                    "commune": item.get("organization", {}).get("name", "France"),
                    "departement": "Transport Data"
                })
    except Exception as e:
        print(f"Erreur API transport.data.gouv.fr: {e}")
        raise Exception(f"Impossible de récupérer les données de gares: {str(e)}")
    
    # Essayer également l'API SNCF Connect
    try:
        url = "https://api.sncf-connect.com/v1/coverage/sncf/places"
        params = {"q": name}
        headers = {"Accept": "application/json"}
        response = requests.get(url, params=params, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            for place in data.get("places", [])[:5]:
                if "stop_area" in place.get("embedded_type", ""):
                    stations.append({
                        "name": place.get("name", ""),
                        "code": place.get("id", ""),
                        "commune": place.get("administrative_region", {}).get("name", ""),
                        "departement": "SNCF"
                    })
    except Exception as e:
        print(f"Erreur API SNCF Connect: {e}")
    
    if not stations:
        raise Exception(f"Aucune gare trouvée pour '{name}' dans les APIs disponibles")
    
    return stations

def get_real_time_trains_mantes():
    """Récupère les horaires temps réel pour Mantes via l'API SIRI Lite SNCF."""
    trains = []
    
    try:
        # API SIRI Lite SNCF - données temps réel
        url = 'https://proxy.transport.data.gouv.fr/resource/sncf-siri-lite-estimated-timetable'
        response = requests.get(url, timeout=30)
        
        if response.status_code == 200:
            # Parser le XML
            root = ET.fromstring(response.content)
            
            # Espaces de noms XML
            namespaces = {
                'siri': 'http://www.siri.org.uk/siri'
            }
            
            # Trouver tous les voyages
            journeys = root.findall('.//siri:EstimatedVehicleJourney', namespaces)
            
            for journey in journeys:
                # Vérifier si c'est un voyage qui concerne Mantes
                has_mantes = False
                mantes_calls = []
                
                # Rechercher dans les arrêts estimés
                estimated_calls = journey.findall('.//siri:EstimatedCall', namespaces)
                
                for call in estimated_calls:
                    stop_name_elem = call.find('siri:StopPointName', namespaces)
                    if stop_name_elem is not None:
                        stop_name = stop_name_elem.text
                        if stop_name and 'mantes' in stop_name.lower():
                            has_mantes = True
                            
                            # Extraire les informations d'horaire
                            arrival_elem = call.find('.//siri:ExpectedArrivalTime', namespaces)
                            departure_elem = call.find('.//siri:ExpectedDepartureTime', namespaces)
                            platform_elem = call.find('.//siri:ArrivalPlatformName', namespaces)
                            
                            arrival_time = arrival_elem.text if arrival_elem is not None else None
                            departure_time = departure_elem.text if departure_elem is not None else None
                            platform = platform_elem.text if platform_elem is not None else ""
                            
                            mantes_calls.append({
                                'stop_name': stop_name,
                                'arrival_time': arrival_time,
                                'departure_time': departure_time,
                                'platform': platform
                            })
                
                if has_mantes:
                    # Extraire les informations du voyage
                    line_ref_elem = journey.find('siri:LineRef', namespaces)
                    origin_elem = journey.find('.//siri:OriginName', namespaces)
                    destination_elem = journey.find('.//siri:DestinationName', namespaces)
                    vehicle_ref_elem = journey.find('siri:VehicleRef', namespaces)
                    
                    line_ref = line_ref_elem.text if line_ref_elem is not None else ""
                    origin = origin_elem.text if origin_elem is not None else ""
                    destination = destination_elem.text if destination_elem is not None else ""
                    train_number = vehicle_ref_elem.text if vehicle_ref_elem is not None else ""
                    
                    for call in mantes_calls:
                        trains.append({
                            'train_number': train_number,
                            'line': line_ref,
                            'origin': origin,
                            'destination': destination,
                            'stop_name': call['stop_name'],
                            'arrival_time': call['arrival_time'],
                            'departure_time': call['departure_time'],
                            'platform': call['platform'],
                            'status': 'real_time',
                            'source': 'SNCF SIRI Lite'
                        })
            
            # Trier par heure d'arrivée/départ
            trains.sort(key=lambda x: x['arrival_time'] or x['departure_time'] or '')
            
        else:
            raise Exception(f"Erreur API SIRI Lite: {response.status_code}")
            
    except Exception as e:
        print(f"Erreur récupération temps réel Mantes: {e}")
        raise e
    
    return trains

def get_train_schedules(station_name, limit=50):
    """Récupère les horaires de trains pour une gare donnée via des APIs réelles uniquement."""
    schedules = []
    
    # Essayer l'API SNCF Connect
    try:
        url = "https://api.sncf-connect.com/v1/coverage/sncf/stop_areas"
        headers = {"Accept": "application/json"}
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            print(f"Données SNCF Connect récupérées pour {station_name}")
            
            # Traiter les données réelles si disponibles
            for stop_area in data.get("stop_areas", [])[:limit]:
                if station_name.lower() in stop_area.get("name", "").lower():
                    # Récupérer les horaires pour cette gare
                    departures_url = f"https://api.sncf-connect.com/v1/coverage/sncf/stop_areas/{stop_area.get('id')}/departures"
                    dep_response = requests.get(departures_url, headers=headers, timeout=10)
                    
                    if dep_response.status_code == 200:
                        dep_data = dep_response.json()
                        for departure in dep_data.get("departures", []):
                            stop_time = departure.get("stop_date_time", {})
                            route_info = departure.get("route", {})
                            schedules.append({
                                "train_number": route_info.get("name", "N/A"),
                                "departure_time": stop_time.get("departure_date_time", ""),
                                "arrival_time": stop_time.get("arrival_date_time", ""),
                                "destination": departure.get("display_informations", {}).get("headsign", ""),
                                "platform": "",
                                "status": stop_time.get("data_freshness", "real_time"),
                                "route": route_info.get("line", {}).get("code", ""),
                                "type": "real"
                            })
                            
    except Exception as e:
        print(f"Erreur API SNCF Connect: {e}")
    
    # Essayer l'API Navitia (alternative)
    if not schedules:
        try:
            url = "https://api.navitia.io/v1/coverage/fr-idf/places"
            params = {"q": station_name}
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                print(f"Données Navitia récupérées pour {station_name}")
                
                for place in data.get("places", []):
                    if place.get("embedded_type") == "stop_area":
                        stop_area_id = place.get("id")
                        
                        # Récupérer les départs
                        departures_url = f"https://api.navitia.io/v1/coverage/fr-idf/stop_areas/{stop_area_id}/departures"
                        dep_response = requests.get(departures_url, timeout=10)
                        
                        if dep_response.status_code == 200:
                            dep_data = dep_response.json()
                            for departure in dep_data.get("departures", []):
                                stop_time = departure.get("stop_date_time", {})
                                display_info = departure.get("display_informations", {})
                                schedules.append({
                                    "train_number": display_info.get("code", "N/A"),
                                    "departure_time": stop_time.get("departure_date_time", ""),
                                    "arrival_time": stop_time.get("arrival_date_time", ""),
                                    "destination": display_info.get("headsign", ""),
                                    "platform": "",
                                    "status": "real_time",
                                    "route": display_info.get("network", ""),
                                    "type": "real"
                                })
                        break
                        
        except Exception as e:
            print(f"Erreur API Navitia: {e}")
    
    # Essayer l'API Transport.data.gouv.fr pour les horaires GTFS
    if not schedules:
        try:
            url = "https://transport.data.gouv.fr/api/datasets"
            params = {"q": f"horaires {station_name}", "type": "public-transit"}
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                print(f"Données Transport.data.gouv.fr récupérées pour {station_name}")
                # Cette API retourne des datasets, pas des horaires directs
                # Il faudrait télécharger et parser les fichiers GTFS
                
        except Exception as e:
            print(f"Erreur API Transport.data.gouv.fr: {e}")
    
    if not schedules:
        raise Exception(f"Aucun horaire disponible pour '{station_name}' dans les APIs réelles")
    
    return schedules[:limit]

@app.route("/")
def home():
    """Page d'accueil avec interface web moderne."""
    return render_template('modern.html')

@app.route("/old")
def old_interface():
    """Ancienne interface web."""
    return render_template('index.html')

@app.route("/api")
def api_info():
    """Informations sur l'API (endpoint JSON)."""
    return jsonify({
        "message": "API Transport SNCF - Données réelles uniquement",
        "status": "running",
        "source": "SNCF Connect + Navitia + Transport.data.gouv.fr",
        "data_policy": "Aucune donnée de démonstration - APIs réelles requises",
        "endpoints": {
            "/": "Interface web interactive",
            "/api": "Informations API (JSON)",
            "/arrivals": "Horaires d'arrivée (param: ?stop=nom_gare)",
            "/mantes": "Horaires pour Mantes-la-Jolie",
            "/mantes-real-time": "Horaires TEMPS RÉEL pour Mantes (SIRI Lite)",
            "/mantes-station-data": "Données complètes de Mantes Station",
            "/stations": "Rechercher des gares (param: ?q=nom)",
            "/available-stations": "Liste toutes les gares avec données temps réel",
            "/test": "Test de connexion APIs réelles"
        }
    })

@app.route("/stations")
def stations():
    """Rechercher des gares par nom via APIs réelles uniquement."""
    query = request.args.get("q", "")
    if not query:
        return jsonify({"error": "Paramètre 'q' requis pour la recherche"}), 400
    
    try:
        stations = find_station_by_name(query)
        return jsonify({
            "query": query,
            "count": len(stations),
            "stations": stations,
            "source": "APIs réelles",
            "status": "success"
        })
    except Exception as e:
        return jsonify({
            "query": query,
            "count": 0,
            "stations": [],
            "error": str(e),
            "source": "Aucune",
            "status": "error"
        }), 404

@app.route("/mantes-real-time")
def mantes_real_time():
    """Récupère les horaires temps réel pour Mantes via l'API SIRI Lite SNCF."""
    try:
        trains = get_real_time_trains_mantes()
        
        return jsonify({
            "station": "Mantes-la-Jolie / Mantes Station",
            "count": len(trains),
            "source": "SNCF SIRI Lite - Temps réel",
            "trains": trains,
            "timestamp": datetime.now().isoformat(),
            "status": "success",
            "note": "Horaires de trains en temps réel (pas d'ouverture de gare)"
        })
        
    except Exception as e:
        return jsonify({
            "station": "Mantes-la-Jolie / Mantes Station",
            "count": 0,
            "source": "SNCF SIRI Lite",
            "trains": [],
            "error": str(e),
            "timestamp": datetime.now().isoformat(),
            "status": "error"
        }), 500

@app.route("/mantes-station-data")
def mantes_station_data():
    """Récupère toutes les données disponibles pour Mantes Station."""
    try:
        # Télécharger les données des horaires de gares
        url = "https://www.data.gouv.fr/api/1/datasets/r/530f823a-6501-4bf2-898d-bf76763969de"
        response = requests.get(url, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            
            # Rechercher toutes les données de Mantes Station
            mantes_data = []
            for item in data:
                if isinstance(item, dict):
                    nom = item.get('nom_normal', '').lower()
                    if 'mantes' in nom:
                        mantes_data.append(item)
            
            if mantes_data:
                # Organiser les données par jour
                schedule_by_day = {}
                station_info = {
                    "name": mantes_data[0].get('nom_normal'),
                    "uic_code": mantes_data[0].get('uic'),
                    "total_entries": len(mantes_data)
                }
                
                for entry in mantes_data:
                    jour = entry.get('jour', 'Unknown')
                    horaire_normal = entry.get('horaire_normal')
                    horaire_ferie = entry.get('horaire_ferie')
                    
                    schedule_by_day[jour] = {
                        "horaire_normal": horaire_normal,
                        "horaire_ferie": horaire_ferie,
                        "status": "Ouvert" if horaire_normal else "Fermé"
                    }
                
                # Données additionnelles sur la gare
                additional_info = {
                    "location": "Mantes-la-Jolie, Yvelines (78)",
                    "region": "Île-de-France",
                    "ligne_principale": "Paris Saint-Lazare - Caen/Cherbourg",
                    "services": ["Guichet", "Distributeurs", "Accès PMR"],
                    "zone_tarifaire": "Zone 5 (Navigo)"
                }
                
                return jsonify({
                    "station_info": station_info,
                    "horaires_par_jour": schedule_by_day,
                    "additional_info": additional_info,
                    "data_source": "Transport.data.gouv.fr - Horaires des gares",
                    "last_updated": datetime.now().isoformat(),
                    "note": "Ces horaires concernent l'ouverture des services de gare, pas les horaires de trains"
                })
            else:
                raise Exception("Mantes Station non trouvée dans les données")
                
        else:
            raise Exception(f"Erreur de téléchargement: {response.status_code}")
            
    except Exception as e:
        return jsonify({
            "error": str(e),
            "station_info": None,
            "timestamp": datetime.now().isoformat()
        }), 500

@app.route("/available-stations")
def available_stations():
    """Liste les gares disponibles avec des données en temps réel."""
    try:
        # Télécharger les données des horaires de gares
        url = "https://www.data.gouv.fr/api/1/datasets/r/530f823a-6501-4bf2-898d-bf76763969de"
        response = requests.get(url, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            
            # Extraire les gares uniques
            stations = {}
            for item in data:
                if isinstance(item, dict):
                    uic = item.get('uic')
                    nom = item.get('nom_normal')
                    if uic and nom:
                        if uic not in stations:
                            stations[uic] = {
                                "name": nom,
                                "uic_code": uic,
                                "operating_hours": {},
                                "real_time_available": True,
                                "data_type": "opening_hours"
                            }
                        
                        # Ajouter les horaires par jour
                        jour = item.get('jour', 'Unknown')
                        horaire = item.get('horaire_normal', 'N/A')
                        stations[uic]["operating_hours"][jour] = horaire
            
            # Convertir en liste et trier
            stations_list = list(stations.values())
            stations_list.sort(key=lambda x: x["name"])
            
            # Rechercher spécifiquement Mantes
            mantes_station = None
            for station in stations_list:
                if 'mantes' in station["name"].lower():
                    mantes_station = station
                    break
            
            return jsonify({
                "total_stations": len(stations_list),
                "data_source": "Transport.data.gouv.fr - Horaires des gares",
                "real_time_type": "Station operating hours only",
                "mantes_la_jolie": {
                    "found": mantes_station is not None,
                    "name": mantes_station["name"] if mantes_station else None,
                    "uic_code": mantes_station["uic_code"] if mantes_station else None,
                    "note": "Listed as 'Mantes Station' in dataset"
                },
                "sample_stations": stations_list[:20],  # Premiers 20 pour l'exemple
                "all_stations_count": len(stations_list),
                "timestamp": datetime.now().isoformat()
            })
        else:
            raise Exception(f"Erreur de téléchargement: {response.status_code}")
            
    except Exception as e:
        return jsonify({
            "error": str(e),
            "total_stations": 0,
            "data_source": "Unavailable",
            "timestamp": datetime.now().isoformat()
        }), 500

@app.route("/test")
def test():
    """Test de connexion avec les APIs de transport réelles uniquement."""
    test_results = []
    
    # Test 1: API SNCF Connect
    try:
        url = "https://api.sncf-connect.com/v1/coverage/sncf"
        response = requests.get(url, timeout=10)
        test_results.append({
            "api": "SNCF Connect",
            "status": "success" if response.status_code == 200 else "error",
            "code": response.status_code,
            "message": "API SNCF Connect accessible" if response.status_code == 200 else f"Erreur {response.status_code}"
        })
    except Exception as e:
        test_results.append({
            "api": "SNCF Connect",
            "status": "error",
            "code": "timeout",
            "message": f"Connexion impossible: {str(e)}"
        })
    
    # Test 2: API Navitia
    try:
        url = "https://api.navitia.io/v1/coverage/fr-idf"
        response = requests.get(url, timeout=10)
        test_results.append({
            "api": "Navitia",
            "status": "success" if response.status_code == 200 else "error",
            "code": response.status_code,
            "message": "API Navitia accessible" if response.status_code == 200 else f"Erreur {response.status_code}"
        })
    except Exception as e:
        test_results.append({
            "api": "Navitia",
            "status": "error",
            "code": "timeout",
            "message": f"Connexion impossible: {str(e)}"
        })
    
    # Test 3: Transport.data.gouv.fr
    try:
        url = "https://transport.data.gouv.fr/api/datasets"
        response = requests.get(url, timeout=10)
        test_results.append({
            "api": "Transport Data Gouv",
            "status": "success" if response.status_code == 200 else "error",
            "code": response.status_code,
            "message": "API Transport.data.gouv.fr accessible" if response.status_code == 200 else f"Erreur {response.status_code}"
        })
    except Exception as e:
        test_results.append({
            "api": "Transport Data Gouv",
            "status": "error", 
            "code": "timeout",
            "message": f"Connexion impossible: {str(e)}"
        })
    
    # Déterminer le statut global
    working_apis = [result for result in test_results if result["status"] == "success"]
    
    if working_apis:
        status = "success"
        message = f"{len(working_apis)} API(s) fonctionnelle(s) sur {len(test_results)}"
    else:
        status = "error"
        message = "Aucune API de transport accessible - Service indisponible"
    
    return jsonify({
        "status": status,
        "message": message,
        "api_tests": test_results,
        "working_apis_count": len(working_apis),
        "total_apis": len(test_results),
        "timestamp": datetime.now().isoformat()
    })

@app.route("/arrivals")
def arrivals():
    """Récupère les horaires d'arrivée/départ pour une gare."""
    station_name = request.args.get("stop", "Mantes la Jolie")
    
    try:
        # Récupérer uniquement les vraies données
        schedules = get_train_schedules(station_name)
        
        return jsonify({
            "station_name": station_name,
            "count": len(schedules),
            "source": "APIs réelles (SNCF Connect / Navitia / Transport.data.gouv.fr)",
            "trains": schedules,
            "timestamp": datetime.now().isoformat(),
            "status": "success"
        })
        
    except Exception as e:
        return jsonify({
            "station_name": station_name,
            "count": 0,
            "source": "Aucune",
            "trains": [],
            "error": str(e),
            "timestamp": datetime.now().isoformat(),
            "status": "error"
        }), 404

@app.route("/mantes")
def mantes():
    # endpoint rapide pour Mantes-la-Jolie
    return arrivals()

if __name__ == "__main__":
    # mode debug désactivé par défaut
    app.run(host="0.0.0.0", port=5000)
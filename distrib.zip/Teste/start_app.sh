#!/bin/bash

# Script de lancement pour le système RFID Distributer
# Usage: ./start_app.sh [--dev|--prod]

# Couleurs
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Vérification de l'environnement virtuel
if [[ "$VIRTUAL_ENV" == "" ]]; then
    print_warning "Environnement virtuel non activé!"
    if [ -d "venv" ]; then
        print_status "Activation de l'environnement virtuel..."
        source venv/bin/activate
    else
        print_error "Environnement virtuel 'venv' non trouvé!"
        print_status "Créez-le avec: python3 -m venv venv"
        exit 1
    fi
fi

# Changement vers le répertoire Flask
cd flask_web 2>/dev/null || {
    print_error "Répertoire flask_web non trouvé!"
    print_status "Assurez-vous d'être dans le bon répertoire"
    exit 1
}

# Vérification des permissions série
if ! groups | grep -q "dialout"; then
    print_warning "Vous n'êtes pas dans le groupe 'dialout'"
    print_warning "Exécutez: sudo usermod -a -G dialout $USER"
    print_warning "Puis reconnectez-vous!"
fi

# Détection automatique de l'Arduino
print_status "Vérification de la connexion Arduino..."
python3 detect_port.py

# Mode de lancement
MODE="dev"
if [ "$1" == "--prod" ]; then
    MODE="prod"
    print_status "Mode PRODUCTION"
elif [ "$1" == "--dev" ]; then
    MODE="dev"
    print_status "Mode DÉVELOPPEMENT"
else
    print_status "Mode DÉVELOPPEMENT (par défaut)"
fi

# Variables d'environnement pour Flask
export FLASK_APP=app.py
export FLASK_ENV=development

if [ "$MODE" == "prod" ]; then
    export FLASK_ENV=production
    export FLASK_DEBUG=0
    print_status "Lancement en mode production..."
    python3 app.py --host=0.0.0.0 --port=5000
else
    export FLASK_DEBUG=1
    print_status "Lancement en mode développement..."
    print_success "Application accessible sur:"
    echo "  - Local: http://localhost:5000"
    echo "  - Réseau: http://$(hostname -I | awk '{print $1}'):5000"
    echo ""
    print_warning "Appuyez sur Ctrl+C pour arrêter"
    python3 app.py
fi
# Distributeur RFID - Installation Linux

## 🐧 Installation sur Lubuntu/Ubuntu

### Installation automatique (recommandée)

```bash
# 1. Rendre le script exécutable
chmod +x install_linux.sh

# 2. Lancer l'installation
./install_linux.sh
```

### Installation manuelle

```bash
# 1. Installer les dépendances système
sudo apt update
sudo apt install python3 python3-pip python3-venv git minicom

# 2. Ajouter l'utilisateur au groupe dialout
sudo usermod -a -G dialout $USER
# IMPORTANT: Se reconnecter après cette commande!

# 3. Créer l'environnement virtuel
python3 -m venv venv
source venv/bin/activate

# 4. Installer les packages Python
pip install -r requirements.txt

# 5. Détecter l'Arduino
cd flask_web
python3 detect_port.py
```

## 🚀 Utilisation

### Lancement rapide
```bash
./start_app.sh
```

### Lancement manuel
```bash
source venv/bin/activate
cd flask_web
python3 app.py
```

## 🔧 Configuration

### Ports série courants sur Linux:
- `/dev/ttyUSB0` - Adaptateur USB-Série générique
- `/dev/ttyACM0` - Arduino Uno/Mega original
- `/dev/ttyUSB1` - Deuxième adaptateur USB

### Auto-détection du port Arduino:
```bash
cd flask_web
python3 detect_port.py
```

### Vérification manuelle des ports:
```bash
# Lister tous les ports série
ls /dev/tty*

# Tester un port avec minicom
minicom -D /dev/ttyUSB0
```

## 🛠️ Dépannage

### Arduino non détecté
1. Vérifier la connexion USB
2. Installer les drivers:
   ```bash
   sudo apt install arduino-core
   ```
3. Vérifier les permissions:
   ```bash
   groups $USER | grep dialout
   ```

### Erreur de permission
```bash
# Ajouter au groupe dialout
sudo usermod -a -G dialout $USER

# Se reconnecter ou redémarrer
logout
```

### Port occupé
```bash
# Voir qui utilise le port
sudo lsof /dev/ttyUSB0

# Arrêter les processus si nécessaire
sudo pkill -f ttyUSB0
```

## 📁 Structure du projet

```
Teste/
├── install_linux.sh      # Installation automatique
├── start_app.sh          # Script de lancement
├── setup_permissions.sh  # Configuration permissions
├── requirements.txt      # Dépendances Python
├── flask_web/
│   ├── app.py            # Application Flask principale
│   ├── config.json       # Configuration (port: /dev/ttyUSB0)
│   ├── detect_port.py    # Détection automatique Arduino
│   └── ...
└── python_controller/
    └── ax12_controller.py # Contrôleur servo (compatible Linux)
```

## 🌐 Accès réseau

L'application sera accessible sur:
- **Local**: http://localhost:5000
- **Réseau**: http://[IP_DU_PC]:5000

Pour connaître l'IP:
```bash
hostname -I
```

## 🔄 Démarrage automatique (optionnel)

Pour lancer automatiquement au démarrage:

```bash
# Créer un service systemd
sudo nano /etc/systemd/system/rfid-distributor.service
```

Contenu du service:
```ini
[Unit]
Description=RFID Distributor Service
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/path/to/Teste
ExecStart=/path/to/Teste/start_app.sh --prod
Restart=always

[Install]
WantedBy=multi-user.target
```

Puis:
```bash
sudo systemctl enable rfid-distributor
sudo systemctl start rfid-distributor
```